package com.clipkeep.ui

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.clipkeep.service.ClipCapture
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val fmt = SimpleDateFormat("MM/dd HH:mm", Locale.getDefault())

fun formatTime(ms: Long): String = fmt.format(Date(ms))

fun copyToClipboard(context: Context, text: String) {
    ClipCapture.putToClipboard(context, text)
    Toast.makeText(context, "コピーしました", Toast.LENGTH_SHORT).show()
}

fun shareText(context: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(i, "共有"))
}

@Composable
fun TextEditDialog(
    title: String,
    initialText: String = "",
    initialTitle: String? = null,
    withTitle: Boolean = true,
    confirmLabel: String = "保存",
    onDismiss: () -> Unit,
    onConfirm: (text: String, title: String?) -> Unit
) {
    var body by remember { mutableStateOf(TextFieldValue(initialText)) }
    var name by remember { mutableStateOf(TextFieldValue(initialTitle ?: "")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (withTitle) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("見出し（任意）") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                OutlinedTextField(
                    value = body,
                    onValueChange = { body = it },
                    label = { Text("本文") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 300.dp)
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = body.text.isNotBlank(),
                onClick = { onConfirm(body.text, name.text.ifBlank { null }) }
            ) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("キャンセル") } }
    )
}

@Composable
fun SingleFieldDialog(
    title: String,
    initial: String = "",
    label: String = "名前",
    confirmLabel: String = "OK",
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var v by remember { mutableStateOf(TextFieldValue(initial)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = v, onValueChange = { v = it },
                label = { Text(label) }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(enabled = v.text.isNotBlank(), onClick = { onConfirm(v.text.trim()) }) {
                Text(confirmLabel)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("キャンセル") } }
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String = "削除",
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("キャンセル") } }
    )
}

@Composable
fun EmptyState(message: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(32.dp)
        )
    }
}
