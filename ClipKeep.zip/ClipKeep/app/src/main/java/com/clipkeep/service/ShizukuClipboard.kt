package com.clipkeep.service

import android.content.ClipData
import android.content.Context
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.Process
import android.util.Log
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method

/**
 * Shizuku を通してクリップボードを読む。
 *
 * Android 10 以降、通常のアプリはバックグラウンドで getPrimaryClip() を呼べない。
 * Shizuku が起動していれば ADB（shell）権限でシステムの clipboard サービスに直接話しかけられるので、
 * フォーカスが無くても内容を取得できる。これが「完全自動」を実現している部分。
 *
 * IClipboard は非公開APIで、getPrimaryClip の引数がAndroidバージョンごとに違う。
 * そのため引数を型から組み立てて呼ぶことで幅広いバージョンを1本のコードで通している。
 */
object ShizukuClipboard {

    private const val TAG = "ShizukuClipboard"

    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"

    /** shell(uid 2000) として呼ぶので、呼び出し元パッケージ名は shell のものを名乗る必要がある。 */
    private const val SHELL_PACKAGE = "com.android.shell"

    enum class State {
        /** Shizuku アプリが入っていない */
        NOT_INSTALLED,
        /** 入っているが起動していない（端末再起動後はここになる） */
        NOT_RUNNING,
        /** 起動しているが ClipKeep に許可を出していない */
        PERMISSION_REQUIRED,
        /** 使える */
        READY
    }

    @Volatile private var service: Any? = null
    @Volatile private var method: Method? = null

    /** 連続失敗時のバックオフ。恒久的に無効化せず、時間を置いて再挑戦する。 */
    @Volatile private var failCount = 0
    @Volatile private var nextRetryAt = 0L

    fun state(context: Context): State {
        val installed = runCatching {
            context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
            true
        }.getOrDefault(false)
        if (!installed) return State.NOT_INSTALLED

        return try {
            when {
                !Shizuku.pingBinder() -> State.NOT_RUNNING
                Shizuku.isPreV11() -> State.NOT_RUNNING
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
                else -> State.PERMISSION_REQUIRED
            }
        } catch (t: Throwable) {
            State.NOT_RUNNING
        }
    }

    /** 読み取りを試してよいか。バックオフ中は false。 */
    fun isReady(): Boolean {
        if (System.currentTimeMillis() < nextRetryAt) return false
        return try {
            Shizuku.pingBinder() &&
                !Shizuku.isPreV11() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (t: Throwable) {
            false
        }
    }

    fun requestPermission(requestCode: Int) {
        runCatching { Shizuku.requestPermission(requestCode) }
    }

    /** 権限が下りた／バインダを受け取った直後に呼ぶ。キャッシュと失敗カウントを捨てる。 */
    fun reset() {
        service = null
        method = null
        failCount = 0
        nextRetryAt = 0L
    }

    /** 現在のクリップボードのテキスト。取れなければ null。 */
    fun readText(context: Context): String? {
        if (!isReady()) return null
        return try {
            val svc = obtainService() ?: run { backOff(); return null }
            val m = obtainMethod(svc) ?: run { backOff(); return null }
            val clip = m.invoke(svc, *buildArgs(m)) as? ClipData
            failCount = 0
            if (clip == null) null else coerce(context, clip)
        } catch (t: Throwable) {
            Log.w(TAG, "clipboard read via Shizuku failed", t)
            service = null
            method = null
            backOff()
            null
        }
    }

    /** 失敗するたびに待ち時間を倍にする（最大5分）。 */
    private fun backOff() {
        failCount = (failCount + 1).coerceAtMost(10)
        val wait = (5_000L shl (failCount - 1).coerceAtMost(6)).coerceAtMost(300_000L)
        nextRetryAt = System.currentTimeMillis() + wait
        Log.d(TAG, "backing off for ${wait / 1000}s (fail #$failCount)")
    }

    private fun obtainService(): Any? {
        service?.let { return it }
        return try {
            val binder: IBinder = SystemServiceHelper.getSystemService("clipboard") ?: return null
            val stub = Class.forName("android.content.IClipboard\$Stub")
            val asInterface = stub.getMethod("asInterface", IBinder::class.java)
            asInterface.invoke(null, ShizukuBinderWrapper(binder))?.also { service = it }
        } catch (t: Throwable) {
            Log.w(TAG, "cannot bind clipboard service", t)
            null
        }
    }

    private fun obtainMethod(svc: Any): Method? {
        method?.let { return it }
        val candidates = svc.javaClass.methods.filter {
            it.name == "getPrimaryClip" && ClipData::class.java.isAssignableFrom(it.returnType)
        }
        // 引数が多いものほど新しいAPI
        return candidates.maxByOrNull { it.parameterTypes.size }?.also { method = it }
    }

    /**
     * 引数を型の並びから組み立てる。
     *   1つ目の String  = 呼び出し元パッケージ
     *   2つ目の String  = attributionTag（null でよい）
     *   1つ目の int     = userId
     *   2つ目の int     = deviceId（仮想ディスプレイ用。既定は 0）
     * 見知らぬプリミティブ型が来ても invoke が落ちないよう既定値を入れておく。
     */
    private fun buildArgs(m: Method): Array<Any?> {
        val userId = Process.myUid() / 100_000
        var stringSeen = 0
        var intSeen = 0
        return m.parameterTypes.map { p ->
            when (p) {
                String::class.java -> if (stringSeen++ == 0) SHELL_PACKAGE else null
                Int::class.javaPrimitiveType -> if (intSeen++ == 0) userId else 0
                Long::class.javaPrimitiveType -> 0L
                Boolean::class.javaPrimitiveType -> false
                Float::class.javaPrimitiveType -> 0f
                Double::class.javaPrimitiveType -> 0.0
                else -> null
            }
        }.toTypedArray()
    }

    private fun coerce(context: Context, clip: ClipData): String? {
        val sb = StringBuilder()
        for (i in 0 until clip.itemCount) {
            val t = clip.getItemAt(i).coerceToText(context)
            if (!t.isNullOrEmpty()) {
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(t)
            }
        }
        return sb.toString().ifBlank { null }
    }
}
