package com.clipkeep.ui

import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyItemScope
import androidx.compose.foundation.lazy.LazyListItemInfo
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.channels.Channel

/**
 * 長押しして掴み、上下にドラッグして並べ替えるための状態。
 * 掴んでいる間は画面上のリストだけを動かし、指を離した時点でDBに書き込む。
 */
class DragDropState internal constructor(
    private val state: LazyListState,
    private val onMove: (from: Int, to: Int) -> Unit,
    private val onDrop: () -> Unit
) {
    var draggingItemIndex by mutableStateOf<Int?>(null)
        private set

    internal val scrollChannel = Channel<Float>()

    private var draggedDelta by mutableFloatStateOf(0f)
    private var initialOffset by mutableIntStateOf(0)

    private val draggingItemInfo: LazyListItemInfo?
        get() = draggingItemIndex?.let { idx ->
            state.layoutInfo.visibleItemsInfo.firstOrNull { it.index == idx }
        }

    /** 掴んでいる行を指に追従させるためのズレ幅。 */
    val draggingItemOffset: Float
        get() = draggingItemInfo?.let { initialOffset + draggedDelta - it.offset } ?: 0f

    internal fun onDragStart(offset: Offset) {
        state.layoutInfo.visibleItemsInfo
            .firstOrNull { offset.y.toInt() in it.offset..(it.offset + it.size) }
            ?.also {
                draggingItemIndex = it.index
                initialOffset = it.offset
            }
    }

    internal fun onDragInterrupted() {
        val wasDragging = draggingItemIndex != null
        draggingItemIndex = null
        draggedDelta = 0f
        if (wasDragging) onDrop()
    }

    internal fun onDrag(offset: Offset) {
        if (draggingItemIndex == null) return
        draggedDelta += offset.y

        val dragging = draggingItemInfo ?: return
        val start = dragging.offset + draggingItemOffset
        val end = start + dragging.size
        val middle = start + (end - start) / 2f

        val target = state.layoutInfo.visibleItemsInfo.firstOrNull { item ->
            middle.toInt() in item.offset..(item.offset + item.size) && item.index != dragging.index
        }

        if (target != null) {
            onMove(dragging.index, target.index)
            draggingItemIndex = target.index
        } else {
            // 端まで来たら自動で少しスクロールする
            val overshoot = when {
                draggedDelta > 0 -> (end - state.layoutInfo.viewportEndOffset).coerceAtLeast(0f)
                draggedDelta < 0 -> (start - state.layoutInfo.viewportStartOffset).coerceAtMost(0f)
                else -> 0f
            }
            if (overshoot != 0f) scrollChannel.trySend(overshoot)
        }
    }
}

@Composable
fun rememberDragDropState(
    listState: LazyListState,
    onMove: (Int, Int) -> Unit,
    onDrop: () -> Unit
): DragDropState {
    val state = remember(listState) { DragDropState(listState, onMove, onDrop) }
    LaunchedEffect(state) {
        while (true) {
            val diff = state.scrollChannel.receive()
            listState.scrollBy(diff)
        }
    }
    return state
}

/** LazyColumn 自体に付ける。長押しでドラッグが始まる。 */
fun Modifier.dragContainer(dragDropState: DragDropState): Modifier =
    pointerInput(dragDropState) {
        detectDragGesturesAfterLongPress(
            onDragStart = { offset -> dragDropState.onDragStart(offset) },
            onDrag = { change, amount ->
                change.consume()
                dragDropState.onDrag(amount)
            },
            onDragEnd = { dragDropState.onDragInterrupted() },
            onDragCancel = { dragDropState.onDragInterrupted() }
        )
    }

/** 各行をこれで包む。掴まれている行だけ浮き上がって指に追従する。 */
@Composable
fun LazyItemScope.DraggableItem(
    dragDropState: DragDropState,
    index: Int,
    enabled: Boolean = true,
    content: @Composable (isDragging: Boolean) -> Unit
) {
    val dragging = enabled && index == dragDropState.draggingItemIndex
    val modifier = if (dragging) {
        Modifier
            .zIndex(1f)
            .graphicsLayer { translationY = dragDropState.draggingItemOffset }
            .shadow(6.dp)
    } else {
        Modifier.animateItem()
    }
    Column(modifier) { content(dragging) }
}
