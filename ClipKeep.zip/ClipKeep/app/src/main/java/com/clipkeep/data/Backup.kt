package com.clipkeep.data

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 書き出し・読み込みのデータ形式。
 *
 * JSON はタブ・見出し・日時をそのまま往復できる正確な形式。
 * テキストはメモ帳で編集しやすい形式で、こちらも読み込める。
 * 取り込み時は中身を見て自動判別する。
 */
object Backup {

    const val VERSION = 1
    private const val MARK = "@@"

    private val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.JAPAN)

    /** タブ名は順番を保ったまま持つ。clips の category はタブ名で参照する。 */
    data class Bundle(
        val categories: List<String> = emptyList(),
        val clips: List<Item> = emptyList()
    ) {
        val historyCount get() = clips.count { !it.pinned }
        val snippetCount get() = clips.count { it.pinned }
    }

    data class Item(
        val text: String,
        val title: String? = null,
        val pinned: Boolean = false,
        val category: String? = null,
        val createdAt: Long = System.currentTimeMillis(),
        val position: Int = 0
    )

    // ==================== タブのパス ====================

    /** ["仕事", "メール"] → "仕事/メール"。名前の中の / と \\ は退避する。 */
    fun encodePath(parts: List<String>): String =
        parts.joinToString("/") { it.replace("\\", "\\\\").replace("/", "\\/") }

    /** "仕事/メール" → ["仕事", "メール"] */
    fun decodePath(path: String): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        var i = 0
        while (i < path.length) {
            val c = path[i]
            when {
                c == '\\' && i + 1 < path.length -> { cur.append(path[i + 1]); i += 2 }
                c == '/' -> { out.add(cur.toString().trim()); cur.setLength(0); i++ }
                else -> { cur.append(c); i++ }
            }
        }
        out.add(cur.toString().trim())
        return out
    }

    // ==================== 書き出し ====================

    fun toJson(b: Bundle): String {
        val root = JSONObject()
        root.put("app", "ClipKeep")
        root.put("version", VERSION)
        root.put("exportedAt", stamp.format(Date()))

        root.put("categories", JSONArray().apply { b.categories.forEach { put(it) } })

        val arr = JSONArray()
        b.clips.forEach { c ->
            arr.put(JSONObject().apply {
                put("text", c.text)
                if (c.title != null) put("title", c.title)
                put("pinned", c.pinned)
                if (c.category != null) put("category", c.category)
                put("createdAt", stamp.format(Date(c.createdAt)))
                put("position", c.position)
            })
        }
        root.put("clips", arr)
        return root.toString(2)
    }

    fun toText(b: Bundle): String = buildString {
        appendLine("# ClipKeep バックアップ (v$VERSION)")
        appendLine("# ${stamp.format(Date())}")
        appendLine("#")
        appendLine("# 編集のしかた")
        appendLine("#   ・「$MARK 」で始まる行が1件の始まり。次の行から本文です。")
        appendLine("#   ・タブ定義  →  $MARK タブ | タブ名")
        appendLine("#   ・定型文    →  $MARK 定型文 | タブ名 | 見出し | 日時   （日時以降は省略可）")
        appendLine("#   ・履歴      →  $MARK 履歴 | 日時 | 見出し           （見出しは省略可）")
        appendLine("#   ・タブ名や見出しに | を使いたいときは \\| と書いてください。")
        appendLine("#   ・本文の行頭に $MARK を書きたいときは \\$MARK と書いてください。")
        appendLine("#   ・行頭が # の行はこの説明部分だけ無視されます。本文中の # はそのまま残ります。")
        appendLine()

        b.categories.forEach {
            appendLine("$MARK タブ | ${escField(it)}")
            appendLine()
        }
        b.clips.forEach { c ->
            val date = stamp.format(Date(c.createdAt))
            if (c.pinned) {
                appendLine(
                    "$MARK 定型文 | ${escField(c.category ?: "")} | ${escField(c.title ?: "")} | $date"
                )
            } else {
                appendLine("$MARK 履歴 | $date | ${escField(c.title ?: "")}")
            }
            appendLine(escapeBody(c.text))
            appendLine()
        }
    }

    /** 見出し行の中の | と \\ を安全にする。タブ名に | が入っていても壊れない。 */
    private fun escField(s: String): String =
        s.replace("\\", "\\\\").replace("|", "\\|")

    /** エスケープされていない | だけで区切る。 */
    private fun splitHeader(h: String): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        var i = 0
        while (i < h.length) {
            val c = h[i]
            when {
                c == '\\' && i + 1 < h.length -> { cur.append(h[i + 1]); i += 2 }
                c == '|' -> { out.add(cur.toString().trim()); cur.setLength(0); i++ }
                else -> { cur.append(c); i++ }
            }
        }
        out.add(cur.toString().trim())
        return out
    }

    private fun escapeBody(text: String): String =
        text.lines().joinToString("\n") { if (it.startsWith(MARK)) "\\$it" else it }

    private fun unescapeBody(text: String): String =
        text.lines().joinToString("\n") { if (it.startsWith("\\$MARK")) it.substring(1) else it }

    // ==================== 読み込み ====================

    /** 中身から形式を見分けて読み込む。壊れていれば null。 */
    fun parse(raw: String): Bundle? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return null
        return if (trimmed.startsWith("{")) parseJson(trimmed) else parseText(raw)
    }

    private fun parseJson(raw: String): Bundle? = runCatching {
        val root = JSONObject(raw)

        val cats = mutableListOf<String>()
        root.optJSONArray("categories")?.let { a ->
            for (i in 0 until a.length()) {
                // 文字列でも {"name": "..."} でも受け付ける
                val v = a.opt(i)
                val name = when (v) {
                    is String -> v
                    is JSONObject -> v.optString("name")
                    else -> null
                }
                if (!name.isNullOrBlank()) cats.add(name)
            }
        }

        val clips = mutableListOf<Item>()
        val a = root.optJSONArray("clips") ?: JSONArray()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val text = o.optString("text")
            if (text.isBlank()) continue
            clips.add(
                Item(
                    text = text,
                    title = o.optString("title").ifBlank { null },
                    pinned = o.optBoolean("pinned", false),
                    category = o.optString("category").ifBlank { null },
                    createdAt = parseDate(o.optString("createdAt")),
                    position = o.optInt("position", i)
                )
            )
        }
        Bundle(cats, clips)
    }.getOrNull()

    private fun parseText(raw: String): Bundle? {
        val lines = raw.replace("\r\n", "\n").split("\n")

        val cats = mutableListOf<String>()
        val clips = mutableListOf<Item>()

        var header: List<String>? = null
        val body = StringBuilder()
        var seenFirstRecord = false

        fun flush() {
            val h = header ?: return
            val text = unescapeBody(body.toString()).trim('\n')
            header = null
            body.setLength(0)

            val kind = h.getOrNull(0)?.trim().orEmpty()
            when {
                kind.startsWith("タブ") || kind.equals("tab", true) -> {
                    val name = h.getOrNull(1)?.trim().orEmpty()
                    if (name.isNotBlank() && cats.none { it == name }) cats.add(name)
                }
                kind.startsWith("定型") || kind.equals("snippet", true) -> {
                    if (text.isNotBlank()) {
                        val cat = h.getOrNull(1)?.trim()?.ifBlank { null }
                        clips.add(
                            Item(
                                text = text,
                                title = h.getOrNull(2)?.trim()?.ifBlank { null },
                                pinned = true,
                                category = cat,
                                // 日時は省略可。無ければ今の時刻になる
                                createdAt = parseDate(h.getOrNull(3)?.trim().orEmpty()),
                                position = clips.size
                            )
                        )
                        if (cat != null && cats.none { it == cat }) cats.add(cat)
                    }
                }
                kind.startsWith("履歴") || kind.equals("history", true) -> {
                    if (text.isNotBlank()) {
                        clips.add(
                            Item(
                                text = text,
                                title = h.getOrNull(2)?.trim()?.ifBlank { null },
                                pinned = false,
                                createdAt = parseDate(h.getOrNull(1)?.trim().orEmpty()),
                                position = clips.size
                            )
                        )
                    }
                }
            }
        }

        for (line in lines) {
            if (line.startsWith("$MARK ")) {
                flush()
                seenFirstRecord = true
                header = splitHeader(line.removePrefix("$MARK "))
                continue
            }
            // 最初のレコードより前の # 行だけを説明文として捨てる
            if (!seenFirstRecord) {
                if (line.startsWith("#") || line.isBlank()) continue
                // 見出しの無い本文は無視する
                continue
            }
            if (header != null) body.appendLine(line)
        }
        flush()

        if (cats.isEmpty() && clips.isEmpty()) return null
        return Bundle(cats, clips)
    }

    private fun parseDate(s: String): Long {
        if (s.isBlank()) return System.currentTimeMillis()
        // まず既定の形式、だめならいくつか試す
        for (pattern in DATE_PATTERNS) {
            runCatching {
                return SimpleDateFormat(pattern, Locale.JAPAN).parse(s.trim())!!.time
            }
        }
        // 数値（エポックミリ秒）も受け付ける
        s.trim().toLongOrNull()?.let { return it }
        return System.currentTimeMillis()
    }

    private val DATE_PATTERNS = listOf(
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd HH:mm",
        "yyyy/MM/dd HH:mm:ss",
        "yyyy/MM/dd HH:mm",
        "yyyy-MM-dd"
    )
}
