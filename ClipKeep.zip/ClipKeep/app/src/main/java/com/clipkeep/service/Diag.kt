package com.clipkeep.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 自動記録がどこで止まっているのかを画面から確認するための記録。
 * 「コピーの検知 → フォーカス取得 → 読み取り → 保存」のどの段階まで進んだかが分かる。
 * ファイルにも外部にも出さず、アプリを終了すると消える。
 */
object Diag {

    private const val MAX = 150
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.JAPAN)

    private val lines = ArrayDeque<String>()

    private val _log = MutableStateFlow<List<String>>(emptyList())
    val logLines: StateFlow<List<String>> = _log

    @Volatile var enabled: Boolean = true

    fun log(msg: String) {
        if (!enabled) return
        synchronized(lines) {
            lines.addLast("${fmt.format(Date())}  $msg")
            while (lines.size > MAX) lines.removeFirst()
            _log.value = lines.toList()
        }
    }

    fun clear() {
        synchronized(lines) {
            lines.clear()
            _log.value = emptyList()
        }
    }

    /** 共有用に新しい順で1つの文字列にする。 */
    fun dump(): String = _log.value.asReversed().joinToString("\n")

    fun short(s: CharSequence?, max: Int = 40): String {
        val t = s?.toString()?.replace('\n', '⏎') ?: return "-"
        return if (t.length > max) t.take(max) + "…" else t
    }
}
