package com.clipkeep.service

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.clipkeep.R
import com.clipkeep.data.Settings
import kotlinx.coroutines.launch

/** 常駐通知を出し続けるだけのサービス。プロセスが殺されにくくなる効果もある。 */
class ClipForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationHelper.ensureChannel(this)

        // startForeground は startForegroundService から数秒以内に同期で呼ぶ必要があるため、
        // まず最小の通知で前面化し、中身はあとから差し替える。
        runCatching { startForegroundCompat(placeholder()) }

        ClipCapture.scope.launch {
            runCatching {
                val n = NotificationHelper.build(this@ClipForegroundService)
                NotificationManagerCompat.from(this@ClipForegroundService)
                    .notify(NotificationHelper.NOTIF_ID, n)
            }
        }
        return START_STICKY
    }

    private fun placeholder(): Notification =
        NotificationCompat.Builder(this, NotificationHelper.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_clip)
            .setContentTitle("ClipKeep")
            .setContentText("準備中…")
            .setOngoing(true)
            .setSilent(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun startForegroundCompat(n: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NotificationHelper.NOTIF_ID, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NotificationHelper.NOTIF_ID, n)
        }
    }

    companion object {
        fun start(context: Context) {
            if (!Settings(context).notificationEnabled) return
            val i = Intent(context, ClipForegroundService::class.java)
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    context.startForegroundService(i)
                else context.startService(i)
            }
        }

        fun stop(context: Context) {
            runCatching { context.stopService(Intent(context, ClipForegroundService::class.java)) }
        }
    }
}
