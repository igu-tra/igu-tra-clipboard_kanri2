package com.clipkeep.service

import android.app.Notification
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.clipkeep.R
import com.clipkeep.data.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * 常駐通知を出しつつ、Shizuku が使えるときはクリップボードを自動監視する。
 *
 * 監視は画面がついている間だけ動く。クリップボードは画面が消えている間に変わらないので、
 * これで電池を無駄に食わずに済む。
 * Shizuku が使えない間は待ち時間を伸ばし、無駄な起床を避ける。
 */
class ClipForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var watchJob: Job? = null
    private var screenReceiver: BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> startWatching()
                    Intent.ACTION_SCREEN_OFF -> stopWatching()
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        // すべて保護されたシステムブロードキャストなので exported フラグは不要
        registerReceiver(screenReceiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationHelper.ensureChannel(this)

        // startForegroundService の 5 秒ウォッチドッグは既に動いている。
        // ここで失敗を握りつぶすと RemoteServiceException でプロセスごと落とされるので、
        // 失敗したら自分から止まる。
        val ok = runCatching { startForegroundCompat(placeholder()) }.isSuccess
        if (!ok) {
            Log.w(TAG, "startForeground failed; stopping")
            stopSelf()
            return START_NOT_STICKY
        }

        val settings = Settings(this)
        if (settings.notificationEnabled) {
            scope.launch {
                runCatching {
                    val n = NotificationHelper.build(this@ClipForegroundService)
                    NotificationManagerCompat.from(this@ClipForegroundService)
                        .notify(NotificationHelper.NOTIF_ID, n)
                }
            }
        }

        // 設定変更やバインダ到着を確実に反映させるため、毎回張り直す
        stopWatching()
        if (isScreenOn()) startWatching()
        return START_STICKY
    }

    private fun isScreenOn(): Boolean =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive

    private fun startWatching() {
        val settings = Settings(this)
        if (!settings.autoCaptureEnabled) return
        if (watchJob?.isActive == true) return

        watchJob = scope.launch {
            val interval = settings.pollIntervalMs
            var idleStreak = 0
            while (isActive) {
                if (ShizukuClipboard.isReady()) {
                    idleStreak = 0
                    runCatching { ClipCapture.poll(this@ClipForegroundService) }
                    delay(interval)
                } else {
                    // Shizuku が居ないうちは間隔を伸ばして待つ（最大30秒）
                    idleStreak = (idleStreak + 1).coerceAtMost(6)
                    delay((interval * (1L shl idleStreak)).coerceAtMost(30_000L))
                }
            }
        }
    }

    private fun stopWatching() {
        watchJob?.cancel()
        watchJob = null
    }

    private fun placeholder(): Notification =
        NotificationCompat.Builder(this, NotificationHelper.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_clip)
            .setContentTitle("ClipKeep")
            .setContentText("クリップボードを見張っています")
            .setOngoing(true)
            .setSilent(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun startForegroundCompat(n: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NotificationHelper.NOTIF_ID, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NotificationHelper.NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        stopWatching()
        scope.cancel()
        screenReceiver?.let { runCatching { unregisterReceiver(it) } }
        screenReceiver = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "ClipFgService"

        /**
         * 常駐通知か自動監視のどちらかが有効なら起動する。
         * （フォアグラウンドサービスは通知の表示が必須なので、通知をオフにしていても
         *   最小限の通知は出る。中身のリッチ表示だけが省かれる。）
         */
        fun start(context: Context) {
            val s = Settings(context)
            if (!s.notificationEnabled && !s.autoCaptureEnabled) return
            val i = Intent(context, ClipForegroundService::class.java)
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    context.startForegroundService(i)
                else context.startService(i)
            }
        }

        /** 設定変更後に監視状態を反映させたいときに呼ぶ。 */
        fun restart(context: Context) {
            stop(context)
            start(context)
        }

        fun stop(context: Context) {
            runCatching { context.stopService(Intent(context, ClipForegroundService::class.java)) }
        }
    }
}
