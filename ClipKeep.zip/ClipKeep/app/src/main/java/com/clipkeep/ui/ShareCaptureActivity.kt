package com.clipkeep.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.clipkeep.R
import com.clipkeep.service.ClipCapture

/** 共有シートから「ClipKeepに保存」。 */
class ShareCaptureActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT)
        if (!text.isNullOrBlank()) {
            ClipCapture.save(text, sourceApp = callingPackage)
            Toast.makeText(applicationContext, R.string.saved, Toast.LENGTH_SHORT).show()
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
