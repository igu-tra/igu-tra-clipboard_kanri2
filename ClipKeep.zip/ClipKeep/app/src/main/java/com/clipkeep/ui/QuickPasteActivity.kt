package com.clipkeep.ui

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import com.clipkeep.ClipKeepApp
import com.clipkeep.R
import com.clipkeep.service.ClipCapture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 履歴の1件をクリップボードに戻して即閉じる。 */
class QuickPasteActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(0, 0)
        val id = intent?.getLongExtra(EXTRA_ID, -1L) ?: -1L
        val direct = intent?.getStringExtra(EXTRA_TEXT)

        if (direct != null) {
            apply(direct)
            return
        }
        if (id <= 0) { finish(); return }
        ClipCapture.scope.launch {
            val e = ClipKeepApp.instance.repo.byId(id)
            withContext(Dispatchers.Main) {
                if (e == null) finish() else apply(e.text)
            }
        }
    }

    private fun apply(text: String) {
        ClipCapture.putToClipboard(this, text)
        Toast.makeText(applicationContext, R.string.copied, Toast.LENGTH_SHORT).show()
        finish()
        overridePendingTransition(0, 0)
    }

    companion object {
        const val EXTRA_ID = "id"
        const val EXTRA_TEXT = "text"
    }
}
