package com.clipkeep.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clipkeep.data.Category
import com.clipkeep.data.ClipEntry

@Composable
fun SnippetScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val categories by vm.categories.collectAsStateWithLifecycle()
    val items by vm.visibleSnippets.collectAsStateWithLifecycle()
    val selected by vm.selectedTab.collectAsStateWithLifecycle()

    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ClipEntry?>(null) }
    var moving by remember { mutableStateOf<ClipEntry?>(null) }
    var addingTab by remember { mutableStateOf(false) }
    var reorderMode by remember { mutableStateOf(false) }
    var managingTab by remember { mutableStateOf<Category?>(null) }
    var duplicate by remember { mutableStateOf<DuplicateInfo?>(null) }

    // ドラッグ中は画面上のリストだけを動かし、指を離したらDBへ書き込む
    val local = remember { mutableStateListOf<ClipEntry>() }
    val listState = rememberLazyListState()
    val dragState = rememberDragDropState(
        listState = listState,
        onMove = { from, to ->
            if (from in local.indices && to in local.indices) local.add(to, local.removeAt(from))
        },
        onDrop = { vm.applyOrder(local.map { it.id }) }
    )
    LaunchedEffect(items, selected) {
        if (dragState.draggingItemIndex == null) {
            local.clear()
            local.addAll(items)
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {

            // ---- タブ列 ----
            ScrollableTabRow(
                selectedTabIndex = tabIndexOf(selected, categories),
                edgePadding = 8.dp
            ) {
                Tab(
                    selected = selected == null,
                    onClick = { vm.selectedTab.value = null },
                    text = { Text("すべて") }
                )
                categories.forEach { c ->
                    Tab(
                        selected = selected == c.id,
                        onClick = { vm.selectedTab.value = c.id },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(c.name)
                                if (selected == c.id) {
                                    Spacer(Modifier.width(2.dp))
                                    Icon(
                                        Icons.Default.Edit, "タブを編集",
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickableNoRipple { managingTab = c }
                                    )
                                }
                            }
                        }
                    )
                }
                Tab(
                    selected = selected == MainViewModel.UNCATEGORIZED,
                    onClick = { vm.selectedTab.value = MainViewModel.UNCATEGORIZED },
                    text = { Text("未分類") }
                )
                Tab(
                    selected = false,
                    onClick = { addingTab = true },
                    text = { Icon(Icons.Default.Add, "タブを追加") }
                )
            }

            if (reorderMode) {
                Text(
                    "並び替え中。行を長押しして上下に動かせます。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            if (local.isEmpty()) {
                EmptyState("定型文がありません。\n右下の＋で追加するか、履歴のメニューから「定型文にする」を選んでください。")
            } else {
                ClipList(
                    items = local,
                    listState = listState,
                    dragState = dragState,
                    reorderable = reorderMode,
                    onClick = { copyToClipboard(context, it.text) },
                    onEdit = { editing = it },
                    onShare = { shareText(context, it.text) },
                    onDelete = { vm.delete(it) },
                    onUnpin = { vm.unpin(it) },
                    onMove = { moving = it }
                )
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.End
        ) {
            SmallFloatingActionButton(
                onClick = { reorderMode = !reorderMode },
                containerColor = if (reorderMode) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.surfaceVariant
            ) { Icon(Icons.Default.SwapVert, "並び替え") }

            FloatingActionButton(onClick = { adding = true }) {
                Icon(Icons.Default.Add, "定型文を追加")
            }
        }
    }

    if (adding) {
        TextEditDialog(
            title = "定型文を追加",
            onDismiss = { adding = false },
            onConfirm = { text, title ->
                val cat = selected?.takeIf { it != MainViewModel.UNCATEGORIZED }
                adding = false
                vm.addSnippetChecked(text, title, cat) { existing ->
                    duplicate = DuplicateInfo(existing) { vm.addSnippet(text, title, cat) }
                }
            }
        )
    }

    editing?.let { e ->
        TextEditDialog(
            title = "定型文を編集",
            initialText = e.text,
            initialTitle = e.title,
            onDismiss = { editing = null },
            onConfirm = { text, title ->
                vm.update(e.copy(text = text, title = title, updatedAt = System.currentTimeMillis()))
                editing = null
            }
        )
    }

    moving?.let { e ->
        PickCategoryDialog(
            categories = categories,
            onDismiss = { moving = null },
            onPick = { catId -> moving = null; vm.pin(e, catId) },
            onCreate = { name -> vm.addCategory(name) }
        )
    }

    if (addingTab) {
        SingleFieldDialog(
            title = "タブを追加",
            label = "タブ名",
            onDismiss = { addingTab = false },
            onConfirm = { vm.addCategory(it); addingTab = false }
        )
    }

    duplicate?.let { info ->
        DuplicateSnippetDialog(
            info = info,
            tabName = categories.firstOrNull { it.id == info.existing.categoryId }?.name ?: "未分類",
            onDismiss = { duplicate = null }
        )
    }

    managingTab?.let { c ->
        TabManageDialog(
            category = c,
            onDismiss = { managingTab = null },
            onRename = { vm.renameCategory(c, it); managingTab = null },
            onDelete = { vm.deleteCategory(c); managingTab = null }
        )
    }
}

private fun tabIndexOf(selected: Long?, categories: List<Category>): Int = when (selected) {
    null -> 0
    MainViewModel.UNCATEGORIZED -> categories.size + 1
    else -> categories.indexOfFirst { it.id == selected }.let { if (it < 0) 0 else it + 1 }
}

@Composable
fun PickCategoryDialog(
    categories: List<Category>,
    onDismiss: () -> Unit,
    onPick: (Long?) -> Unit,
    onCreate: (String) -> Unit
) {
    var creating by remember { mutableStateOf(false) }

    if (creating) {
        SingleFieldDialog(
            title = "タブを追加",
            label = "タブ名",
            onDismiss = { creating = false },
            onConfirm = { onCreate(it); creating = false }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("どのタブに入れますか？") },
        text = {
            Column {
                ListItem(
                    headlineContent = { Text("未分類") },
                    modifier = Modifier.clickableNoRipple { onPick(null) }
                )
                categories.forEach { c ->
                    ListItem(
                        headlineContent = { Text(c.name) },
                        modifier = Modifier.clickableNoRipple { onPick(c.id) }
                    )
                }
                TextButton(onClick = { creating = true }) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("新しいタブ")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("閉じる") } }
    )
}

@Composable
private fun TabManageDialog(
    category: Category,
    onDismiss: () -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit
) {
    var renaming by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    when {
        renaming -> SingleFieldDialog(
            title = "タブ名を変更",
            initial = category.name,
            label = "タブ名",
            onDismiss = { renaming = false },
            onConfirm = onRename
        )
        confirmDelete -> ConfirmDialog(
            title = "「${category.name}」を削除",
            message = "中の定型文は消えず、未分類に移動します。",
            onDismiss = { confirmDelete = false },
            onConfirm = onDelete
        )
        else -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(category.name) },
            text = {
                Column {
                    ListItem(
                        headlineContent = { Text("名前を変更") },
                        modifier = Modifier.clickableNoRipple { renaming = true }
                    )
                    ListItem(
                        headlineContent = { Text("このタブを削除") },
                        modifier = Modifier.clickableNoRipple { confirmDelete = true }
                    )
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("閉じる") } }
        )
    }
}

fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)
