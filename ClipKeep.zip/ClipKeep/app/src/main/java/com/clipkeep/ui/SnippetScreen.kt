package com.clipkeep.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clipkeep.data.Category
import com.clipkeep.data.ClipEntry

@Composable
fun SnippetScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val categories by vm.categories.collectAsStateWithLifecycle()
    val mainTabs by vm.mainTabs.collectAsStateWithLifecycle()
    val subTabs by vm.subTabs.collectAsStateWithLifecycle()
    val items by vm.visibleSnippets.collectAsStateWithLifecycle()
    val main by vm.selectedMain.collectAsStateWithLifecycle()
    val sub by vm.selectedSub.collectAsStateWithLifecycle()
    val needsSub by vm.needsSubSelection.collectAsStateWithLifecycle()

    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ClipEntry?>(null) }
    var moving by remember { mutableStateOf<ClipEntry?>(null) }
    var addingMainTab by remember { mutableStateOf(false) }
    var addingSubTab by remember { mutableStateOf<Long?>(null) }
    var managingTab by remember { mutableStateOf<Category?>(null) }
    var reorderMode by remember { mutableStateOf(false) }
    var duplicate by remember { mutableStateOf<DuplicateInfo?>(null) }

    // ドラッグ中は画面上のリストだけを動かし、指を離したらDBへ書き込む
    val local = remember { mutableStateListOf<ClipEntry>() }
    val listState = rememberLazyListState()
    val dragState = rememberDragDropState(
        listState = listState,
        onMove = { from, to ->
            if (from in local.indices && to in local.indices) local.add(to, local.removeAt(from))
        },
        onDrop = { vm.applyOrder(local.map { it.id }) }
    )
    LaunchedEffect(items, main, sub) {
        if (dragState.draggingItemIndex == null) {
            local.clear()
            local.addAll(items)
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {

            // ---------------- 上段: メインタブ ----------------
            ScrollableTabRow(
                selectedTabIndex = mainIndexOf(main, mainTabs),
                edgePadding = 8.dp
            ) {
                Tab(
                    selected = main == null,
                    onClick = { vm.selectMain(null) },
                    text = { Text("すべて") }
                )
                mainTabs.forEach { c ->
                    val hasSubs = categories.any { it.parentId == c.id }
                    Tab(
                        selected = main == c.id,
                        onClick = { vm.selectMain(c.id) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (hasSubs) "${c.name} ▾" else c.name)
                                if (main == c.id) {
                                    Spacer(Modifier.width(2.dp))
                                    Icon(
                                        Icons.Default.Edit, "タブを編集",
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickableNoRipple { managingTab = c }
                                    )
                                }
                            }
                        }
                    )
                }
                Tab(
                    selected = main == MainViewModel.UNCATEGORIZED,
                    onClick = { vm.selectMain(MainViewModel.UNCATEGORIZED) },
                    text = { Text("未分類") }
                )
                Tab(
                    selected = false,
                    onClick = { addingMainTab = true },
                    text = { Icon(Icons.Default.Add, "メインタブを追加") }
                )
            }

            // ---------------- 下段: サブタブ（あるときだけ） ----------------
            if (subTabs.isNotEmpty()) {
                ScrollableTabRow(
                    // 未選択のときに「＋」が選択済みに見えないよう、下線は自前で出さない。
                    // 選択中かどうかは各タブの文字色で分かる。
                    selectedTabIndex = subIndexOf(sub, subTabs).coerceAtLeast(0),
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    divider = {},
                    indicator = {}
                ) {
                    subTabs.forEach { c ->
                        Tab(
                            selected = sub == c.id,
                            onClick = { vm.selectSub(c.id) },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(c.name, style = MaterialTheme.typography.bodySmall)
                                    if (sub == c.id) {
                                        Spacer(Modifier.width(2.dp))
                                        Icon(
                                            Icons.Default.Edit, "サブタブを編集",
                                            modifier = Modifier
                                                .size(14.dp)
                                                .clickableNoRipple { managingTab = c }
                                        )
                                    }
                                }
                            }
                        )
                    }
                    Tab(
                        selected = false,
                        onClick = { main?.let { addingSubTab = it } },
                        text = { Icon(Icons.Default.Add, "サブタブを追加", Modifier.size(18.dp)) }
                    )
                }
            }

            if (reorderMode) {
                Text(
                    "並び替え中。行を長押しして上下に動かせます。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            when {
                needsSub -> EmptyState("上のサブタブを選んでください。")

                local.isEmpty() -> EmptyState(
                    "定型文がありません。\n右下の＋で追加するか、履歴のメニューから「定型文にする」を選んでください。"
                )

                else -> ClipList(
                    items = local,
                    listState = listState,
                    dragState = dragState,
                    reorderable = reorderMode,
                    onClick = { copyToClipboard(context, it.text) },
                    onEdit = { editing = it },
                    onShare = { shareText(context, it.text) },
                    onDelete = { vm.delete(it) },
                    onUnpin = { vm.unpin(it) },
                    onMove = { moving = it }
                )
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.End
        ) {
            SmallFloatingActionButton(
                onClick = { reorderMode = !reorderMode },
                containerColor = if (reorderMode) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.surfaceVariant
            ) { Icon(Icons.Default.SwapVert, "並び替え") }

            FloatingActionButton(
                onClick = {
                    if (needsSub) {
                        Toast.makeText(context, "先に上のサブタブを選んでください", Toast.LENGTH_SHORT).show()
                    } else {
                        adding = true
                    }
                }
            ) { Icon(Icons.Default.Add, "定型文を追加") }
        }
    }

    if (adding) {
        TextEditDialog(
            title = "定型文を追加",
            onDismiss = { adding = false },
            onConfirm = { text, title ->
                val cat = vm.currentTargetCategory()
                adding = false
                vm.addSnippetChecked(text, title, cat) { existing ->
                    duplicate = DuplicateInfo(existing) { vm.addSnippet(text, title, cat) }
                }
            }
        )
    }

    editing?.let { e ->
        TextEditDialog(
            title = "定型文を編集",
            initialText = e.text,
            initialTitle = e.title,
            onDismiss = { editing = null },
            onConfirm = { text, title ->
                vm.update(e.copy(text = text, title = title, updatedAt = System.currentTimeMillis()))
                editing = null
            }
        )
    }

    moving?.let { e ->
        PickCategoryDialog(
            categories = categories,
            onDismiss = { moving = null },
            onPick = { catId -> moving = null; vm.pin(e, catId) },
            onCreate = { name -> vm.addCategory(name) }
        )
    }

    if (addingMainTab) {
        SingleFieldDialog(
            title = "メインタブを追加",
            label = "タブ名",
            onDismiss = { addingMainTab = false },
            onConfirm = { vm.addCategory(it); addingMainTab = false }
        )
    }

    addingSubTab?.let { parentId ->
        val first = categories.none { it.parentId == parentId }
        SingleFieldDialog(
            title = if (first) "最初のサブタブを追加" else "サブタブを追加",
            label = "サブタブ名",
            onDismiss = { addingSubTab = null },
            onConfirm = { vm.addSubCategory(parentId, it); addingSubTab = null }
        )
    }

    duplicate?.let { info ->
        DuplicateSnippetDialog(
            info = info,
            tabName = pathNameOf(categories, info.existing.categoryId),
            onDismiss = { duplicate = null }
        )
    }

    managingTab?.let { c ->
        TabManageDialog(
            category = c,
            hasChildren = categories.any { it.parentId == c.id },
            isSub = c.parentId != null,
            onDismiss = { managingTab = null },
            onRename = { vm.renameCategory(c, it); managingTab = null },
            onAddSub = { managingTab = null; addingSubTab = c.id },
            onDelete = { vm.deleteCategory(c); managingTab = null }
        )
    }
}

private fun mainIndexOf(selected: Long?, mains: List<Category>): Int = when (selected) {
    null -> 0
    MainViewModel.UNCATEGORIZED -> mains.size + 1
    else -> mains.indexOfFirst { it.id == selected }.let { if (it < 0) 0 else it + 1 }
}

private fun subIndexOf(selected: Long?, subs: List<Category>): Int =
    subs.indexOfFirst { it.id == selected }

/** 「仕事 / メール」のように親子をつないだ表示名。 */
fun pathNameOf(categories: List<Category>, catId: Long?): String {
    val c = categories.firstOrNull { it.id == catId } ?: return "未分類"
    val parent = c.parentId?.let { p -> categories.firstOrNull { it.id == p } }
    return if (parent == null) c.name else "${parent.name} / ${c.name}"
}

/**
 * 定型文の保存先を選ぶ。サブタブを持つメインは見出しとして出し、
 * 選べるのはサブタブだけにする（メインとサブに中身が混ざらないようにするため）。
 */
@Composable
fun PickCategoryDialog(
    categories: List<Category>,
    onDismiss: () -> Unit,
    onPick: (Long?) -> Unit,
    onCreate: (String) -> Unit
) {
    var creating by remember { mutableStateOf(false) }

    if (creating) {
        SingleFieldDialog(
            title = "メインタブを追加",
            label = "タブ名",
            onDismiss = { creating = false },
            onConfirm = { onCreate(it); creating = false }
        )
        return
    }

    val mains = categories.filter { it.parentId == null }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("どのタブに入れますか？") },
        text = {
            Column(
                Modifier
                    .heightIn(max = 400.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                ListItem(
                    headlineContent = { Text("未分類") },
                    modifier = Modifier.clickableNoRipple { onPick(null) }
                )
                mains.forEach { m ->
                    val kids = categories.filter { it.parentId == m.id }
                    if (kids.isEmpty()) {
                        ListItem(
                            headlineContent = { Text(m.name) },
                            modifier = Modifier.clickableNoRipple { onPick(m.id) }
                        )
                    } else {
                        Text(
                            m.name,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 16.dp, top = 8.dp)
                        )
                        kids.forEach { k ->
                            ListItem(
                                headlineContent = { Text(k.name) },
                                modifier = Modifier
                                    .padding(start = 24.dp)
                                    .clickableNoRipple { onPick(k.id) }
                            )
                        }
                    }
                }
                TextButton(onClick = { creating = true }) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("新しいメインタブ")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("閉じる") } }
    )
}

@Composable
private fun TabManageDialog(
    category: Category,
    hasChildren: Boolean,
    isSub: Boolean,
    onDismiss: () -> Unit,
    onRename: (String) -> Unit,
    onAddSub: () -> Unit,
    onDelete: () -> Unit
) {
    var renaming by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    when {
        renaming -> SingleFieldDialog(
            title = "タブ名を変更",
            initial = category.name,
            label = "タブ名",
            onDismiss = { renaming = false },
            onConfirm = onRename
        )

        confirmDelete -> ConfirmDialog(
            title = "「${category.name}」を削除",
            message = when {
                hasChildren -> "サブタブもまとめて削除されます。中の定型文は消えず、未分類に移動します。"
                isSub -> "中の定型文は消えません。ほかにサブタブが残っていれば未分類へ、" +
                    "これが最後のサブタブなら親タブの直下へ戻ります。"
                else -> "中の定型文は消えず、未分類に移動します。"
            },
            onDismiss = { confirmDelete = false },
            onConfirm = onDelete
        )

        else -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(category.name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    ListItem(
                        headlineContent = { Text("名前を変更") },
                        modifier = Modifier.clickableNoRipple { renaming = true }
                    )
                    if (!isSub) {
                        ListItem(
                            headlineContent = { Text("サブタブを追加") },
                            supportingContent = {
                                if (!hasChildren) {
                                    Text("最初のサブタブを作ると、このタブの定型文はそこへ移ります")
                                }
                            },
                            modifier = Modifier.clickableNoRipple(onAddSub)
                        )
                    }
                    ListItem(
                        headlineContent = { Text("このタブを削除") },
                        modifier = Modifier.clickableNoRipple { confirmDelete = true }
                    )
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("閉じる") } }
        )
    }
}

fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)
