package com.clipkeep.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.clipkeep.R
import com.clipkeep.service.ClipCapture

/**
 * 文字を選択したときのポップアップメニュー（コピー / 共有 の並び）に
 * 「ClipKeepに保存」として出てくる入口。権限もアクセシビリティも不要で、
 * どのAndroidバージョンでも確実に動く。
 */
class ProcessTextActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            ?: intent?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT_READONLY)?.toString()

        if (!text.isNullOrBlank()) {
            ClipCapture.save(text, sourceApp = callingPackage)
            Toast.makeText(applicationContext, R.string.saved, Toast.LENGTH_SHORT).show()
        }
        setResult(RESULT_OK)
        finish()
        overridePendingTransition(0, 0)
    }
}
