package com.clipkeep.data

import android.content.Context

class Settings(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("clipkeep", Context.MODE_PRIVATE)

    /** 保持件数。0 = 無制限 */
    var historyLimit: Int
        get() = sp.getInt(KEY_LIMIT, DEFAULT_LIMIT).let { if (it <= 0) Int.MAX_VALUE else it }
        set(v) = sp.edit().putInt(KEY_LIMIT, v).apply()

    val rawHistoryLimit: Int get() = sp.getInt(KEY_LIMIT, DEFAULT_LIMIT)

    var notificationEnabled: Boolean
        get() = sp.getBoolean(KEY_NOTIF, true)
        set(v) = sp.edit().putBoolean(KEY_NOTIF, v).apply()

    var notifRecentCount: Int
        get() = sp.getInt(KEY_NOTIF_N, 3)
        set(v) = sp.edit().putInt(KEY_NOTIF_N, v).apply()

    /** Shizuku による自動監視 */
    var autoCaptureEnabled: Boolean
        get() = sp.getBoolean(KEY_AUTO, true)
        set(v) = sp.edit().putBoolean(KEY_AUTO, v).apply()

    /** アクセシビリティで「コピー」を検知したら自動保存する */
    var copyDetectionEnabled: Boolean
        get() = sp.getBoolean(KEY_DETECT, true)
        set(v) = sp.edit().putBoolean(KEY_DETECT, v).apply()

    /** アプリを切り替えたときにもクリップボードを確認する（検知漏れ対策・トーストは増える） */
    var checkOnAppSwitch: Boolean
        get() = sp.getBoolean(KEY_APPSWITCH, false)
        set(v) = sp.edit().putBoolean(KEY_APPSWITCH, v).apply()

    /** 履歴を手動で並び替えるモード */
    var historyManualOrder: Boolean
        get() = sp.getBoolean(KEY_MANUAL, false)
        set(v) = sp.edit().putBoolean(KEY_MANUAL, v).apply()

    /** 監視の間隔（ミリ秒） */
    var pollIntervalMs: Long
        get() = sp.getLong(KEY_POLL, 1000L).coerceIn(300L, 10_000L)
        set(v) = sp.edit().putLong(KEY_POLL, v).apply()

    companion object {
        const val DEFAULT_LIMIT = 1000
        private const val KEY_LIMIT = "history_limit"
        private const val KEY_NOTIF = "notif_enabled"
        private const val KEY_NOTIF_N = "notif_recent"
        private const val KEY_AUTO = "auto_capture"
        private const val KEY_POLL = "poll_interval"
        private const val KEY_DETECT = "copy_detection"
        private const val KEY_MANUAL = "history_manual_order"
        private const val KEY_APPSWITCH = "check_on_app_switch"
    }
}
