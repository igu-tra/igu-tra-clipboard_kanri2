package com.clipkeep.data

import android.content.Context

class Settings(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("clipkeep", Context.MODE_PRIVATE)

    /** 保持件数。0 = 無制限 */
    var historyLimit: Int
        get() = sp.getInt(KEY_LIMIT, DEFAULT_LIMIT).let { if (it <= 0) Int.MAX_VALUE else it }
        set(v) = sp.edit().putInt(KEY_LIMIT, v).apply()

    val rawHistoryLimit: Int get() = sp.getInt(KEY_LIMIT, DEFAULT_LIMIT)

    var notificationEnabled: Boolean
        get() = sp.getBoolean(KEY_NOTIF, true)
        set(v) = sp.edit().putBoolean(KEY_NOTIF, v).apply()

    var notifRecentCount: Int
        get() = sp.getInt(KEY_NOTIF_N, 3)
        set(v) = sp.edit().putInt(KEY_NOTIF_N, v).apply()

    companion object {
        const val DEFAULT_LIMIT = 1000
        private const val KEY_LIMIT = "history_limit"
        private const val KEY_NOTIF = "notif_enabled"
        private const val KEY_NOTIF_N = "notif_recent"
    }
}
