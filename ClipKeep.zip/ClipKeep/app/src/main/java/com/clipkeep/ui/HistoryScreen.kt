package com.clipkeep.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clipkeep.data.ClipEntry

@Composable
fun HistoryScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val items by vm.history.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()

    var editing by remember { mutableStateOf<ClipEntry?>(null) }
    var pinning by remember { mutableStateOf<ClipEntry?>(null) }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { vm.query.value = it },
            placeholder = { Text("履歴を検索") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { vm.query.value = "" }) { Icon(Icons.Default.Clear, null) }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )

        if (items.isEmpty()) {
            EmptyState(
                if (query.isBlank())
                    "まだ履歴がありません。\n通知の「今のコピーを保存」や、文字を長押しして出るメニューの「ClipKeepに保存」から記録できます。"
                else "見つかりませんでした"
            )
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.id }) { e ->
                    ClipRow(
                        entry = e,
                        onClick = { copyToClipboard(context, e.text) },
                        onEdit = { editing = e },
                        onPin = { pinning = e },
                        onShare = { shareText(context, e.text) },
                        onDelete = { vm.delete(e) }
                    )
                    HorizontalDivider()
                }
            }
        }
    }

    editing?.let { e ->
        TextEditDialog(
            title = "編集",
            initialText = e.text,
            initialTitle = e.title,
            onDismiss = { editing = null },
            onConfirm = { text, title ->
                vm.update(e.copy(text = text, title = title, updatedAt = System.currentTimeMillis()))
                editing = null
            }
        )
    }

    pinning?.let { e ->
        PickCategoryDialog(
            categories = categories,
            onDismiss = { pinning = null },
            onPick = { catId ->
                vm.pin(e, catId)
                pinning = null
            },
            onCreate = { name -> vm.addCategory(name) }
        )
    }
}

@Composable
fun ClipRow(
    entry: ClipEntry,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onPin: (() -> Unit)? = null,
    onUnpin: (() -> Unit)? = null,
    onMove: (() -> Unit)? = null,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            if (!entry.title.isNullOrBlank()) {
                Text(
                    entry.title,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                entry.text,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                formatTime(entry.createdAt),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "メニュー") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("編集") }, onClick = { menu = false; onEdit() })
                onPin?.let {
                    DropdownMenuItem(text = { Text("定型文にする") }, onClick = { menu = false; it() })
                }
                onMove?.let {
                    DropdownMenuItem(text = { Text("タブを変更") }, onClick = { menu = false; it() })
                }
                onUnpin?.let {
                    DropdownMenuItem(text = { Text("定型文から外す") }, onClick = { menu = false; it() })
                }
                DropdownMenuItem(text = { Text("共有") }, onClick = { menu = false; onShare() })
                DropdownMenuItem(text = { Text("削除") }, onClick = { menu = false; confirmDelete = true })
            }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = "削除しますか？",
            message = entry.preview,
            onDismiss = { confirmDelete = false },
            onConfirm = { confirmDelete = false; onDelete() }
        )
    }
}
