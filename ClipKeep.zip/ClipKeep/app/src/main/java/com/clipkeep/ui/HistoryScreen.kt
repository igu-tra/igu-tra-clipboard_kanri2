package com.clipkeep.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clipkeep.data.ClipEntry

@Composable
fun HistoryScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val items by vm.history.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val manual by vm.manualOrder.collectAsStateWithLifecycle()

    var editing by remember { mutableStateOf<ClipEntry?>(null) }
    var pinning by remember { mutableStateOf<ClipEntry?>(null) }
    var duplicate by remember { mutableStateOf<DuplicateInfo?>(null) }

    // ドラッグ中は画面上のリストだけを動かし、指を離したらDBへ書き込む
    val local = remember { mutableStateListOf<ClipEntry>() }
    val listState = rememberLazyListState()
    val dragState = rememberDragDropState(
        listState = listState,
        onMove = { from, to ->
            if (from in local.indices && to in local.indices) local.add(to, local.removeAt(from))
        },
        onDrop = { vm.applyOrder(local.map { it.id }) }
    )
    LaunchedEffect(items) {
        if (dragState.draggingItemIndex == null) {
            local.clear()
            local.addAll(items)
        }
    }

    // 並び替えできるのは手動モードかつ検索していないとき
    val reorderable = manual && query.isBlank()

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { vm.query.value = it },
                placeholder = { Text("履歴を検索") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { vm.query.value = "" }) { Icon(Icons.Default.Clear, null) }
                    }
                },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(4.dp))
            IconButton(onClick = { vm.setManualOrder(!manual) }) {
                Icon(
                    Icons.Default.SwapVert,
                    contentDescription = "並び替えモード",
                    tint = if (manual) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (manual) {
            Text(
                if (query.isBlank()) "手動並び替え中。行を長押しして上下に動かせます。新しいコピーは先頭に入ります。"
                else "検索中は並び替えできません。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
            )
        }

        if (local.isEmpty()) {
            EmptyState(
                if (query.isBlank())
                    "まだ履歴がありません。\n文字をコピーすると自動で記録されます（設定でコピー検知を有効にしてください）。"
                else "見つかりませんでした"
            )
        } else {
            ClipList(
                items = local,
                listState = listState,
                dragState = dragState,
                reorderable = reorderable,
                onClick = { copyToClipboard(context, it.text) },
                onEdit = { editing = it },
                onShare = { shareText(context, it.text) },
                onDelete = { vm.delete(it) },
                onPin = { pinning = it }
            )
        }
    }

    editing?.let { e ->
        TextEditDialog(
            title = "編集",
            initialText = e.text,
            initialTitle = e.title,
            onDismiss = { editing = null },
            onConfirm = { text, title ->
                vm.update(e.copy(text = text, title = title, updatedAt = System.currentTimeMillis()))
                editing = null
            }
        )
    }

    pinning?.let { e ->
        PickCategoryDialog(
            categories = categories,
            onDismiss = { pinning = null },
            onPick = { catId ->
                pinning = null
                vm.pinChecked(e, catId) { existing ->
                    duplicate = DuplicateInfo(existing) { vm.pin(e, catId) }
                }
            },
            onCreate = { name -> vm.addCategory(name) }
        )
    }

    duplicate?.let { info ->
        DuplicateSnippetDialog(
            info = info,
            tabName = categories.firstOrNull { it.id == info.existing.categoryId }?.name ?: "未分類",
            onDismiss = { duplicate = null }
        )
    }
}

/** 履歴・定型文で共通のリスト。 */
@Composable
fun ClipList(
    items: SnapshotStateList<ClipEntry>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    dragState: DragDropState,
    reorderable: Boolean,
    onClick: (ClipEntry) -> Unit,
    onEdit: (ClipEntry) -> Unit,
    onShare: (ClipEntry) -> Unit,
    onDelete: (ClipEntry) -> Unit,
    onPin: ((ClipEntry) -> Unit)? = null,
    onUnpin: ((ClipEntry) -> Unit)? = null,
    onMove: ((ClipEntry) -> Unit)? = null
) {
    LazyColumn(
        state = listState,
        modifier = if (reorderable) Modifier
            .fillMaxSize()
            .dragContainer(dragState)
        else Modifier.fillMaxSize()
    ) {
        itemsIndexed(items, key = { _, e -> e.id }) { index, e ->
            DraggableItem(dragState, index, enabled = reorderable) { isDragging ->
                Surface(
                    color = if (isDragging) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent
                ) {
                    Column {
                        ClipRow(
                            entry = e,
                            onClick = { onClick(e) },
                            onEdit = { onEdit(e) },
                            onPin = onPin?.let { f -> { f(e) } },
                            onUnpin = onUnpin?.let { f -> { f(e) } },
                            onMove = onMove?.let { f -> { f(e) } },
                            onShare = { onShare(e) },
                            onDelete = { onDelete(e) }
                        )
                        // 区切り線もドラッグする行の一部にしておく（置き去りにしない）
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
fun ClipRow(
    entry: ClipEntry,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onPin: (() -> Unit)? = null,
    onUnpin: (() -> Unit)? = null,
    onMove: (() -> Unit)? = null,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Row(
        Modifier
            .fillMaxWidth()
            .clickableNoRipple(onClick)
            .padding(start = 16.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            if (!entry.title.isNullOrBlank()) {
                Text(
                    entry.title,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                entry.text,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                formatTime(entry.createdAt),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "メニュー") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("編集") }, onClick = { menu = false; onEdit() })
                onPin?.let {
                    DropdownMenuItem(text = { Text("定型文にする") }, onClick = { menu = false; it() })
                }
                onMove?.let {
                    DropdownMenuItem(text = { Text("タブを変更") }, onClick = { menu = false; it() })
                }
                onUnpin?.let {
                    DropdownMenuItem(text = { Text("定型文から外す") }, onClick = { menu = false; it() })
                }
                DropdownMenuItem(text = { Text("共有") }, onClick = { menu = false; onShare() })
                DropdownMenuItem(text = { Text("削除") }, onClick = { menu = false; confirmDelete = true })
            }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = "削除しますか？",
            message = entry.preview,
            onDismiss = { confirmDelete = false },
            onConfirm = { confirmDelete = false; onDelete() }
        )
    }
}
