package com.clipkeep.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ClipDao {

    // ---- 履歴 ----
    @Query("SELECT * FROM clips WHERE pinned = 0 ORDER BY createdAt DESC")
    fun history(): Flow<List<ClipEntry>>

    @Query("""
        SELECT * FROM clips
        WHERE pinned = 0 AND text LIKE '%' || :q || '%'
        ORDER BY createdAt DESC
    """)
    fun searchHistory(q: String): Flow<List<ClipEntry>>

    @Query("SELECT * FROM clips WHERE pinned = 0 ORDER BY createdAt DESC LIMIT :n")
    suspend fun recent(n: Int): List<ClipEntry>

    @Query("SELECT * FROM clips WHERE pinned = 0 AND text = :text LIMIT 1")
    suspend fun findHistoryByText(text: String): ClipEntry?

    @Query("SELECT COUNT(*) FROM clips WHERE pinned = 0")
    suspend fun historyCount(): Int

    /** 上限を超えた古い履歴だけを消す。ピン留め（定型文）は絶対に消えない。 */
    @Query("""
        DELETE FROM clips
        WHERE pinned = 0 AND id NOT IN (
            SELECT id FROM clips WHERE pinned = 0 ORDER BY createdAt DESC LIMIT :keep
        )
    """)
    suspend fun trimHistory(keep: Int): Int

    @Query("DELETE FROM clips WHERE pinned = 0")
    suspend fun clearHistory()

    // ---- 定型文 ----
    @Query("SELECT * FROM clips WHERE pinned = 1 ORDER BY position ASC, updatedAt DESC")
    fun allSnippets(): Flow<List<ClipEntry>>

    // ---- 共通 ----
    @Query("SELECT * FROM clips WHERE id = :id")
    suspend fun byId(id: Long): ClipEntry?

    @Insert
    suspend fun insert(e: ClipEntry): Long

    @Update
    suspend fun update(e: ClipEntry)

    @Delete
    suspend fun delete(e: ClipEntry)

    @Query("DELETE FROM clips WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM clips")
    suspend fun exportAll(): List<ClipEntry>
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY position ASC, id ASC")
    fun all(): Flow<List<Category>>

    @Query("SELECT * FROM categories ORDER BY position ASC, id ASC")
    suspend fun allOnce(): List<Category>

    @Insert
    suspend fun insert(c: Category): Long

    @Update
    suspend fun update(c: Category)

    @Query("DELETE FROM categories WHERE id = :id")
    suspend fun deleteById(id: Long)

    /** タブを消しても中身は消さず、未分類（NULL）へ退避する。 */
    @Query("UPDATE clips SET categoryId = NULL WHERE categoryId = :id")
    suspend fun detachClips(id: Long)
}
