package com.clipkeep.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ClipDao {

    // ---- 履歴 ----
    @Query("SELECT * FROM clips WHERE pinned = 0 ORDER BY createdAt DESC")
    fun history(): Flow<List<ClipEntry>>

    /** 手動並び替えモードの履歴。 */
    @Query("SELECT * FROM clips WHERE pinned = 0 ORDER BY position ASC, createdAt DESC")
    fun historyManual(): Flow<List<ClipEntry>>

    @Query("""
        SELECT * FROM clips
        WHERE pinned = 0 AND text LIKE '%' || :q || '%'
        ORDER BY position ASC, createdAt DESC
    """)
    fun searchHistoryManual(q: String): Flow<List<ClipEntry>>

    @Query("""
        SELECT * FROM clips
        WHERE pinned = 0 AND text LIKE '%' || :q || '%'
        ORDER BY createdAt DESC
    """)
    fun searchHistory(q: String): Flow<List<ClipEntry>>

    @Query("SELECT * FROM clips WHERE pinned = 0 ORDER BY createdAt DESC LIMIT :n")
    suspend fun recent(n: Int): List<ClipEntry>

    @Query("SELECT * FROM clips WHERE pinned = 0 AND text = :text LIMIT 1")
    suspend fun findHistoryByText(text: String): ClipEntry?

    @Query("SELECT COUNT(*) FROM clips WHERE pinned = 0")
    suspend fun historyCount(): Int

    /** 同じ本文の古い履歴を消して、残す1件だけにする。 */
    @Query("DELETE FROM clips WHERE pinned = 0 AND text = :text AND id != :keepId")
    suspend fun deleteHistoryDuplicates(text: String, keepId: Long): Int

    /** 上限を超えた古い履歴だけを消す。ピン留め（定型文）は絶対に消えない。 */
    @Query("""
        DELETE FROM clips
        WHERE pinned = 0 AND id NOT IN (
            SELECT id FROM clips WHERE pinned = 0 ORDER BY createdAt DESC LIMIT :keep
        )
    """)
    suspend fun trimHistory(keep: Int): Int

    @Query("DELETE FROM clips WHERE pinned = 0")
    suspend fun clearHistory()

    // ---- 定型文 ----
    @Query("SELECT * FROM clips WHERE pinned = 1 ORDER BY position ASC, updatedAt DESC")
    fun allSnippets(): Flow<List<ClipEntry>>

    /** 定型文の重複チェック用。 */
    @Query("SELECT * FROM clips WHERE pinned = 1 AND text = :text AND id != :excludeId LIMIT 1")
    suspend fun findSnippetByText(text: String, excludeId: Long): ClipEntry?

    // ---- 共通 ----
    @Query("SELECT * FROM clips WHERE id = :id")
    suspend fun byId(id: Long): ClipEntry?

    // ---- 並び順 ----
    @Query("UPDATE clips SET position = :pos WHERE id = :id")
    suspend fun updatePosition(id: Long, pos: Int)

    @Query("SELECT MIN(position) FROM clips WHERE pinned = 0")
    suspend fun minHistoryPosition(): Int?

    @Query("SELECT id FROM clips WHERE pinned = 0 ORDER BY createdAt DESC")
    suspend fun historyIdsByTime(): List<Long>

    // ---- バックアップ ----
    @Query("DELETE FROM clips")
    suspend fun deleteAllClips()

    @Insert
    suspend fun insertAll(items: List<ClipEntry>): List<Long>

    @Insert
    suspend fun insert(e: ClipEntry): Long

    @Update
    suspend fun update(e: ClipEntry)

    @Delete
    suspend fun delete(e: ClipEntry)

    @Query("DELETE FROM clips WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM clips")
    suspend fun exportAll(): List<ClipEntry>
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY position ASC, id ASC")
    fun all(): Flow<List<Category>>

    @Query("SELECT * FROM categories ORDER BY position ASC, id ASC")
    suspend fun allOnce(): List<Category>

    @Query("SELECT * FROM categories WHERE parentId IS NULL ORDER BY position ASC, id ASC")
    suspend fun rootsOnce(): List<Category>

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun byId(id: Long): Category?

    @Insert
    suspend fun insert(c: Category): Long

    @Update
    suspend fun update(c: Category)

    @Query("DELETE FROM categories WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM categories WHERE name = :name AND parentId IS :parentId LIMIT 1")
    suspend fun findByName(name: String, parentId: Long?): Category?

    @Query("SELECT * FROM categories WHERE parentId = :parentId ORDER BY position ASC, id ASC")
    suspend fun childrenOf(parentId: Long): List<Category>

    @Query("SELECT COUNT(*) FROM categories WHERE parentId = :parentId")
    suspend fun childCount(parentId: Long): Int

    /** タブの中身をまるごと別のタブ（または未分類）へ移す。 */
    @Query("UPDATE clips SET categoryId = :to WHERE categoryId = :from")
    suspend fun moveClips(from: Long, to: Long?)

    @Query("DELETE FROM categories")
    suspend fun deleteAll()

    /** タブを消しても中身は消さず、未分類（NULL）へ退避する。 */
    @Query("UPDATE clips SET categoryId = NULL WHERE categoryId = :id")
    suspend fun detachClips(id: Long)
}
