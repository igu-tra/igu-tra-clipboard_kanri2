package com.clipkeep.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.clipkeep.ClipKeepApp
import com.clipkeep.R
import com.clipkeep.data.Settings
import com.clipkeep.ui.MainActivity
import com.clipkeep.ui.QuickCaptureActivity
import com.clipkeep.ui.QuickPasteActivity
import kotlinx.coroutines.launch

object NotificationHelper {

    const val CHANNEL_ID = "clipkeep_persistent"
    const val NOTIF_ID = 1001

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) != null) return
        val ch = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "履歴へのショートカットを常に表示します"
            setShowBadge(false)
            enableVibration(false)
            setSound(null, null)
        }
        nm.createNotificationChannel(ch)
    }

    private fun pi(context: Context, intent: Intent, req: Int): PendingIntent =
        PendingIntent.getActivity(
            context, req, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    suspend fun build(context: Context): Notification {
        val settings = Settings(context)
        val recent = runCatching {
            ClipKeepApp.instance.repo.recent(settings.notifRecentCount.coerceIn(0, 5))
        }.getOrDefault(emptyList())

        val openApp = pi(context, Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), 0)

        val capture = pi(context, Intent(context, QuickCaptureActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION), 1)

        val b = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_clip)
            .setContentTitle("ClipKeep")
            .setContentText(
                recent.firstOrNull()?.preview ?: "コピーした文字をここに記録します"
            )
            .setContentIntent(openApp)
            .setOngoing(true)
            .setSilent(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .addAction(R.drawable.ic_clip, "今のコピーを保存", capture)
            .addAction(R.drawable.ic_clip, "履歴を開く", openApp)

        if (recent.isNotEmpty()) {
            val style = NotificationCompat.InboxStyle().setBigContentTitle("最近のコピー")
            recent.forEach { style.addLine(it.preview) }
            b.setStyle(style)
            // 先頭の1件はワンタップでクリップボードに戻せるようにする
            val top = recent.first()
            val paste = pi(
                context,
                Intent(context, QuickPasteActivity::class.java)
                    .putExtra(QuickPasteActivity.EXTRA_ID, top.id)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION),
                2
            )
            b.addAction(R.drawable.ic_clip, "直前をコピー", paste)
        }
        return b.build()
    }

    /** 通知の中身（最近のコピー）を貼り替える。 */
    fun refresh(context: Context) {
        if (!Settings(context).notificationEnabled) return
        ClipCapture.scope.launch {
            runCatching {
                ensureChannel(context)
                NotificationManagerCompat.from(context).notify(NOTIF_ID, build(context))
            }
        }
    }
}
