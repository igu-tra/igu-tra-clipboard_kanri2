package com.clipkeep.ui

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clipkeep.service.Diag

/**
 * 自動記録がどこで止まっているかを確認するための画面。
 * 「コピーの検知 → フォーカス取得 → 読み取り → 保存」のどこまで進んだかが新しい順に並ぶ。
 */
@Composable
fun DiagSection() {
    val context = LocalContext.current
    val lines by Diag.logLines.collectAsStateWithLifecycle()
    var on by remember { mutableStateOf(Diag.enabled) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {

        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("診断ログを記録する", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "コピーしてからこの画面を開くと、何が起きたか分かります。端末の外には出ません。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = on, onCheckedChange = { on = it; Diag.enabled = it })
        }

        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = MaterialTheme.shapes.small,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                Modifier
                    .heightIn(min = 80.dp, max = 260.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(8.dp)
            ) {
                if (lines.isEmpty()) {
                    Text(
                        "まだ記録がありません。\nどこかで文字をコピーしてから、この画面に戻ってきてください。",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        lines.asReversed().joinToString("\n"),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { copyToClipboard(context, Diag.dump()) },
                enabled = lines.isNotEmpty(),
                modifier = Modifier.weight(1f)
            ) { Text("コピー") }

            OutlinedButton(
                onClick = {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, Diag.dump())
                    }
                    context.startActivity(Intent.createChooser(i, "診断ログを送る"))
                },
                enabled = lines.isNotEmpty(),
                modifier = Modifier.weight(1f)
            ) { Text("共有") }

            OutlinedButton(onClick = { Diag.clear() }, modifier = Modifier.weight(1f)) {
                Text("消去")
            }
        }
    }
}
