package com.clipkeep.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clipkeep.data.Category
import com.clipkeep.data.ClipRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 書き出し・読み込みのUI。
 * ファイルの置き場所はAndroidの標準ピッカーに任せるので、ストレージの権限は要らない。
 */
@Composable
fun BackupSection(vm: MainViewModel) {
    val context = LocalContext.current
    val categories by vm.categories.collectAsStateWithLifecycle()

    var showExport by remember { mutableStateOf(false) }
    var pendingScope by remember { mutableStateOf(ClipRepository.Scope.ALL) }
    var pendingCategoryId by remember { mutableStateOf<Long?>(null) }
    var pendingImportUri by remember { mutableStateOf<android.net.Uri?>(null) }

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_LONG).show()

    // コントラクトは equals を持たないので、毎回作り直すとランチャーが登録し直しになる
    val createJson = remember { ActivityResultContracts.CreateDocument("application/json") }
    val createText = remember { ActivityResultContracts.CreateDocument("text/plain") }
    val openDoc = remember { ActivityResultContracts.OpenDocument() }

    val saveJson = rememberLauncherForActivityResult(createJson) { uri ->
        if (uri != null) vm.exportTo(context, uri, pendingScope, pendingCategoryId, true) { toast(it) }
    }
    val saveText = rememberLauncherForActivityResult(createText) { uri ->
        if (uri != null) vm.exportTo(context, uri, pendingScope, pendingCategoryId, false) { toast(it) }
    }
    val openFile = rememberLauncherForActivityResult(openDoc) { uri ->
        if (uri != null) pendingImportUri = uri
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { showExport = true }, modifier = Modifier.weight(1f)) {
                Text("書き出す")
            }
            OutlinedButton(
                onClick = {
                    openFile.launch(arrayOf("application/json", "text/plain", "*/*"))
                },
                modifier = Modifier.weight(1f)
            ) { Text("読み込む") }
        }
        Text(
            "書き出したファイルはメモ帳などで直接編集して、そのまま読み込み直せます。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (showExport) {
        ExportDialog(
            categories = categories,
            onDismiss = { showExport = false },
            onExport = { scope, catId, asJson ->
                pendingScope = scope
                pendingCategoryId = catId
                showExport = false
                val base = fileName(scope, catId, categories)
                if (asJson) saveJson.launch("$base.json") else saveText.launch("$base.txt")
            }
        )
    }

    pendingImportUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingImportUri = null },
            title = { Text("読み込み方法") },
            text = {
                Text(
                    "「追記」は今ある内容を残したまま足します（完全に同じ本文はスキップ）。\n" +
                        "「置き換え」は履歴・定型文・タブをすべて消してからファイルの内容にします。"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    pendingImportUri = null
                    vm.importFrom(context, uri, replace = false) { toast(it) }
                }) { Text("追記") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pendingImportUri = null }) { Text("やめる") }
                    TextButton(onClick = {
                        pendingImportUri = null
                        vm.importFrom(context, uri, replace = true) { toast(it) }
                    }) { Text("置き換え") }
                }
            }
        )
    }
}

@Composable
private fun ExportDialog(
    categories: List<Category>,
    onDismiss: () -> Unit,
    onExport: (ClipRepository.Scope, Long?, Boolean) -> Unit
) {
    var scope by remember { mutableStateOf(ClipRepository.Scope.ALL) }
    var catId by remember { mutableStateOf(categories.firstOrNull()?.id) }
    var asJson by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("書き出す範囲") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ChoiceRow("全部（履歴＋定型文＋タブ）", scope == ClipRepository.Scope.ALL) {
                    scope = ClipRepository.Scope.ALL
                }
                ChoiceRow("履歴だけ", scope == ClipRepository.Scope.HISTORY) {
                    scope = ClipRepository.Scope.HISTORY
                }
                ChoiceRow("定型文すべて", scope == ClipRepository.Scope.SNIPPETS) {
                    scope = ClipRepository.Scope.SNIPPETS
                }
                if (categories.isNotEmpty()) {
                    ChoiceRow("タブを1つ", scope == ClipRepository.Scope.ONE_TAB) {
                        scope = ClipRepository.Scope.ONE_TAB
                    }
                    if (scope == ClipRepository.Scope.ONE_TAB) {
                        Column(Modifier.padding(start = 32.dp)) {
                            categories.forEach { c ->
                                ChoiceRow(c.name, catId == c.id) { catId = c.id }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))

                Text("形式", style = MaterialTheme.typography.labelLarge)
                ChoiceRow("JSON（見出し・タブ・日時をそのまま保持）", asJson) { asJson = true }
                ChoiceRow("テキスト（メモ帳で編集しやすい）", !asJson) { asJson = false }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onExport(scope, if (scope == ClipRepository.Scope.ONE_TAB) catId else null, asJson)
            }) { Text("書き出す") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("やめる") } }
    )
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickableNoRipple(onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

private fun fileName(
    scope: ClipRepository.Scope,
    catId: Long?,
    categories: List<Category>
): String {
    val date = SimpleDateFormat("yyyyMMdd", Locale.JAPAN).format(Date())
    val part = when (scope) {
        ClipRepository.Scope.ALL -> "all"
        ClipRepository.Scope.HISTORY -> "history"
        ClipRepository.Scope.SNIPPETS -> "snippets"
        ClipRepository.Scope.ONE_TAB ->
            categories.firstOrNull { it.id == catId }?.name?.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                ?: "tab"
    }
    return "clipkeep-$part-$date"
}
