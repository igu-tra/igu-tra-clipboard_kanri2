package com.clipkeep.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * バックグラウンドからクリップボードを読むための「一瞬だけフォーカスを取る」仕掛け。
 *
 * Android は「今フォーカスを持っているアプリ」にはクリップボードの読み取りを許す。
 * そこで 1x1 の見えないウィンドウを一瞬だけ足してフォーカスを受け取り、読み終わったら即座に外す。
 * 抜け道ではなく、OSが定めた条件を正面から満たしにいく方法。
 *
 * ウィンドウの種類は2通り試す。
 *   1. TYPE_ACCESSIBILITY_OVERLAY : アクセシビリティサービスから足す。追加の権限が不要
 *   2. TYPE_APPLICATION_OVERLAY   : 1が弾かれる端末（MIUI等）向けの予備。重ねて表示の許可が必要
 *
 * FLAG_ALT_FOCUSABLE_IM を付けているので、ウィンドウのフォーカスは取るが
 * 入力メソッド（キーボード）のフォーカスは奪わない。開いているキーボードは閉じないはず。
 */
object FocusGrabber {

    private const val TAG = "FocusGrabber"
    private const val MIN_INTERVAL_MS = 400L
    private const val SAFETY_TIMEOUT_MS = 1500L

    private val main = Handler(Looper.getMainLooper())

    @Volatile private var busy = false
    @Volatile private var lastAt = 0L

    /** アクセシビリティサービスから呼ぶ。どのスレッドからでもよい。 */
    fun request(service: AccessibilityService) {
        val now = SystemClock.elapsedRealtime()
        if (busy || now - lastAt < MIN_INTERVAL_MS) return
        lastAt = now
        main.post { grab(service) }
    }

    private fun grab(service: AccessibilityService) {
        if (busy) return

        // Shizuku が生きているならフォーカスを触る必要はない
        if (ShizukuClipboard.isReady()) {
            ClipCapture.captureFromClipboard(service)
            return
        }

        val wm = service.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return

        // アクセシビリティ用のウィンドウを優先し、弾かれたら重ねて表示にフォールバックする
        val types = buildList {
            add(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
            if (canDrawOverlays(service)) {
                add(
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        @Suppress("DEPRECATION")
                        WindowManager.LayoutParams.TYPE_PHONE
                )
            }
        }

        busy = true
        var attached: View? = null
        var finished = false

        val cleanup = object : Runnable {
            override fun run() {
                if (finished) return
                finished = true
                attached?.let { v -> runCatching { wm.removeViewImmediate(v) } }
                attached = null
                busy = false
            }
        }

        for (type in types) {
            val v = FocusView(service) {
                // フォーカスが来た＝この瞬間だけ読み取りが許される。
                // 読み終わってから片付ける（先に外すとフォーカスが消えて読めない）。
                ClipCapture.captureFromClipboard(service) { main.post(cleanup) }
            }
            val added = runCatching { wm.addView(v, params(type)) }.isSuccess
            if (added) {
                attached = v
                // フォーカスが来なかった場合でも必ず片付ける
                main.postDelayed(cleanup, SAFETY_TIMEOUT_MS)
                return
            }
            Log.d(TAG, "addView failed for type=$type")
        }

        Log.w(TAG, "could not create a focusable window")
        busy = false
    }

    private fun params(type: Int) = WindowManager.LayoutParams(
        1, 1, 0, 0,
        type,
        // FLAG_NOT_FOCUSABLE は付けない（付けるとフォーカスを取れない）
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        title = "ClipKeep"
    }

    fun canDrawOverlays(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(context)
        else true

    private class FocusView(
        context: Context,
        private val onFocused: () -> Unit
    ) : View(context) {
        private var fired = false
        override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
            super.onWindowFocusChanged(hasWindowFocus)
            if (hasWindowFocus && !fired) {
                fired = true
                onFocused()
            }
        }
    }
}
