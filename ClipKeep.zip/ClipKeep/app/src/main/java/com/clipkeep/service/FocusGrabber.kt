package com.clipkeep.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.clipkeep.ui.QuickCaptureActivity

private fun typeName(type: Int) = when (type) {
    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY -> "アクセシビリティ"
    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY -> "重ねて表示"
    else -> type.toString()
}

/**
 * バックグラウンドからクリップボードを読むための「一瞬だけフォーカスを取る」仕掛け。
 *
 * Android は「今フォーカスを持っているアプリ」にはクリップボードの読み取りを許す。
 * そこで 1x1 の見えないウィンドウを一瞬だけ足してフォーカスを受け取り、読み終わったら即座に外す。
 * 抜け道ではなく、OSが定めた条件を正面から満たしにいく方法。
 *
 * ウィンドウの種類は2通り試す。
 *   1. TYPE_ACCESSIBILITY_OVERLAY : アクセシビリティサービスから足す。追加の権限が不要
 *   2. TYPE_APPLICATION_OVERLAY   : 1が弾かれる端末（MIUI等）向けの予備。重ねて表示の許可が必要
 *
 * FLAG_ALT_FOCUSABLE_IM を付けているので、ウィンドウのフォーカスは取るが
 * 入力メソッド（キーボード）のフォーカスは奪わない。開いているキーボードは閉じないはず。
 */
object FocusGrabber {

    private const val TAG = "FocusGrabber"
    private const val MIN_INTERVAL_MS = 400L
    private const val SAFETY_TIMEOUT_MS = 1500L

    private val main = Handler(Looper.getMainLooper())

    @Volatile private var busy = false
    @Volatile private var lastAt = 0L

    /**
     * 見えない窓でフォーカスを受け取れるかどうか。
     * 端末によっては受け取れないので、一度失敗したら以降は透明アクティビティ方式に切り替える。
     */
    @Volatile private var overlayFocusWorks = true

    /** 窓方式でフォーカスが来なかった回数。たまたま1回外しただけで見限らない。 */
    @Volatile private var overlayMisses = 0

    /** アクセシビリティサービスから呼ぶ。どのスレッドからでもよい。 */
    fun request(service: AccessibilityService) {
        val now = SystemClock.elapsedRealtime()
        if (busy) { Diag.log("  取得中のため見送り"); return }
        if (now - lastAt < MIN_INTERVAL_MS) { Diag.log("  短時間の連続のため見送り"); return }
        lastAt = now
        main.post { grab(service) }
    }

    private fun grab(service: AccessibilityService) {
        if (busy) return

        // Shizuku が生きているならフォーカスを触る必要はない
        if (ShizukuClipboard.isReady()) {
            Diag.log("  Shizuku経由で読み取り")
            ClipCapture.captureFromClipboard(service)
            return
        }

        // 過去に窓方式が失敗している端末では、最初からアクティビティ方式でいく
        if (!overlayFocusWorks) {
            Diag.log("  窓方式は使えない端末のためアクティビティで読み取り")
            launchCaptureActivity(service)
            return
        }

        val wm = service.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return

        // アクセシビリティ用のウィンドウを優先し、弾かれたら重ねて表示にフォールバックする
        val types = buildList {
            add(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
            if (canDrawOverlays(service)) {
                add(
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        @Suppress("DEPRECATION")
                        WindowManager.LayoutParams.TYPE_PHONE
                )
            }
        }

        busy = true
        var attached: View? = null
        var finished = false
        var focused = false

        val cleanup = object : Runnable {
            override fun run() {
                if (finished) return
                finished = true
                if (!focused) {
                    overlayMisses++
                    if (overlayMisses >= 3) {
                        overlayFocusWorks = false
                        Diag.log("  フォーカスが来ません（${overlayMisses}回目）→ 以後アクティビティ方式にします")
                    } else {
                        Diag.log("  フォーカスが来ませんでした（${overlayMisses}回目）")
                    }
                    main.post { launchCaptureActivity(service) }
                }
                attached?.let { v -> runCatching { wm.removeViewImmediate(v) } }
                attached = null
                busy = false
            }
        }

        for (type in types) {
            val v = FocusView(service) {
                // フォーカスが来た＝この瞬間だけ読み取りが許される。
                // 読み終わってから片付ける（先に外すとフォーカスが消えて読めない）。
                focused = true
                overlayMisses = 0
                Diag.log("  フォーカス取得 OK")
                ClipCapture.captureFromClipboard(service) { main.post(cleanup) }
            }
            val result = runCatching { wm.addView(v, params(type)) }
            val added = result.isSuccess
            Diag.log("  窓を追加 type=${typeName(type)} → ${if (added) "OK" else "失敗: " + result.exceptionOrNull()?.javaClass?.simpleName}")
            if (added) {
                attached = v
                // フォーカスが来なかった場合でも必ず片付ける
                main.postDelayed(cleanup, SAFETY_TIMEOUT_MS)
                return
            }
            Log.d(TAG, "addView failed for type=$type")
        }

        Diag.log("  フォーカス用の窓を作れませんでした → アクティビティ方式に切り替えます")
        Log.w(TAG, "could not create a focusable window")
        overlayFocusWorks = false
        busy = false
        launchCaptureActivity(service)
    }

    private fun params(type: Int) = WindowManager.LayoutParams(
        1, 1, 0, 0,
        type,
        // FLAG_NOT_FOCUSABLE は付けない（付けるとフォーカスを取れない）
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        title = "ClipKeep"
    }

    /**
     * 透明なアクティビティを一瞬だけ立ち上げて読む、最後の手段。
     * アクティビティは確実にフォーカスを持てるので、これが失敗することはまずない。
     */
    private fun launchCaptureActivity(context: Context) {
        val i = Intent(context, QuickCaptureActivity::class.java)
            .putExtra(QuickCaptureActivity.EXTRA_SILENT, true)
            .addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or
                    Intent.FLAG_ACTIVITY_NO_HISTORY
            )
        // 「重ねて表示」が無いとバックグラウンドからの起動はOSに黙って握り潰される。
        // startActivity 自体は例外を投げないので、権限の有無を先に見て正直に記録する。
        if (!canDrawOverlays(context)) {
            Diag.log("  ✕ アクティビティを起動できません。「重ねて表示」を許可してください")
            return
        }
        val ok = runCatching { context.startActivity(i) }.isSuccess
        Diag.log("  アクティビティ起動 → ${if (ok) "OK" else "失敗"}")
    }

    fun canDrawOverlays(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(context)
        else true

    private class FocusView(
        context: Context,
        private val onFocused: () -> Unit
    ) : View(context) {
        private var fired = false
        override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
            super.onWindowFocusChanged(hasWindowFocus)
            if (hasWindowFocus && !fired) {
                fired = true
                onFocused()
            }
        }
    }
}
