package com.clipkeep.ui

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import com.clipkeep.R
import com.clipkeep.service.ClipCapture

/**
 * 透明なアクティビティ。一瞬だけフォーカスを取ることで Android 10+ の
 * クリップボード読み取り制限を正規の手順で通過し、内容を保存してすぐ閉じる。
 * 通知の「今のコピーを保存」ボタン / クイック設定タイルから呼ばれる。
 */
class QuickCaptureActivity : Activity() {

    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(0, 0)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !done) {
            done = true
            ClipCapture.captureFromClipboard(this) { text ->
                val msg = if (text != null) getString(R.string.saved) else getString(R.string.capture_failed)
                Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
                finish()
                overridePendingTransition(0, 0)
            }
        }
    }
}
