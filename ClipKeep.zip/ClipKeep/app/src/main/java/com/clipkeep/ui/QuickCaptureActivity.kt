package com.clipkeep.ui

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.clipkeep.R
import com.clipkeep.service.ClipCapture

/**
 * 透明なアクティビティ。一瞬だけフォーカスを取ることで Android 10+ の
 * クリップボード読み取り制限を正規の手順で通過し、内容を保存してすぐ閉じる。
 * 通知の「今のコピーを保存」ボタン / クイック設定タイルから呼ばれる。
 */
class QuickCaptureActivity : Activity() {

    private var done = false
    private val handler = Handler(Looper.getMainLooper())
    private val timeout = Runnable { if (!done) capture() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(0, 0)
    }

    override fun onResume() {
        super.onResume()
        // フォーカスが来ないまま放置されると透明画面が残るので、保険をかけておく
        handler.postDelayed(timeout, 1200)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) capture()
    }

    private fun capture() {
        if (done) return
        done = true
        handler.removeCallbacks(timeout)
        val silent = intent?.getBooleanExtra(EXTRA_SILENT, false) ?: false
        ClipCapture.captureFromClipboard(this) { text ->
            if (!silent) {
                val msg = if (text != null) getString(R.string.saved)
                else getString(R.string.capture_failed)
                Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
            }
            finish()
            overridePendingTransition(0, 0)
        }
    }

    companion object {
        /** 自動記録から呼ばれたときは黙って処理する */
        const val EXTRA_SILENT = "silent"
    }

    override fun onDestroy() {
        handler.removeCallbacks(timeout)
        super.onDestroy()
    }
}
