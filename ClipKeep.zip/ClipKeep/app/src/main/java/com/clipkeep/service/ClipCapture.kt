package com.clipkeep.service

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.util.Log
import com.clipkeep.ClipKeepApp
import com.clipkeep.data.ClipRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * クリップボード読み取りの共通処理。
 *
 * 読み取り経路は優先順に3つ。
 *   1. Shizuku 経由（バックグラウンドでも読める＝完全自動の本命）
 *   2. 通常の ClipboardManager（自分にフォーカスがあるときだけ成功）
 *   3. テキストを直接渡してもらう（文字選択メニュー・共有シート）
 */
object ClipCapture {

    private const val TAG = "ClipCapture"
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** 直前に記録した本文。同じものを何度も保存しないための番人。 */
    @Volatile private var lastSeen: String? = null

    private fun repo(): ClipRepository = ClipKeepApp.instance.repo

    /**
     * 今のクリップボードを読んで保存する。
     * バインダ越しの読み取りはブロックしうるので必ず別スレッドで行い、
     * onDone だけメインスレッドに戻す。
     */
    fun captureFromClipboard(context: Context, onDone: ((String?) -> Unit)? = null) {
        scope.launch {
            val text = readAny(context)?.takeIf { it.isNotBlank() }
            if (text != null) save(text, sourceApp = null)
            if (onDone != null) withContext(Dispatchers.Main) { onDone(text) }
        }
    }

    /** 監視ループ用。前回と同じなら何もしない。 */
    fun poll(context: Context) {
        val text = readAny(context) ?: return
        if (text.trim() == lastSeen) return
        save(text, sourceApp = null)
    }

    private fun readAny(context: Context): String? {
        ShizukuClipboard.readText(context)?.let {
            Diag.log("  読み取り成功(Shizuku) ${it.length}文字")
            return it
        }
        return try {
            val t = readViaManager(context)
            if (t == null) Diag.log("  読み取り: 中身なし")
            else Diag.log("  読み取り成功 ${t.length}文字: ${Diag.short(t, 30)}")
            t
        } catch (e: SecurityException) {
            Diag.log("  読み取り拒否（フォーカスが無い）")
            Log.d(TAG, "clipboard read denied", e)
            null
        } catch (t: Throwable) {
            Diag.log("  読み取り失敗: ${t.javaClass.simpleName}")
            Log.d(TAG, "clipboard read failed: ${t.message}")
            null
        }
    }

    private fun readViaManager(context: Context): String? {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        if (!cm.hasPrimaryClip()) return null
        val clip: ClipData = cm.primaryClip ?: return null
        val sb = StringBuilder()
        for (i in 0 until clip.itemCount) {
            val t = clip.getItemAt(i).coerceToText(context)
            if (!t.isNullOrEmpty()) {
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(t)
            }
        }
        return sb.toString().ifBlank { null }
    }

    /** 任意のテキストを履歴に保存する。 */
    fun save(text: String, sourceApp: String?) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (t == lastSeen) { Diag.log("  直前と同じ内容なので保存しない"); return }
        lastSeen = t
        Diag.log("  ★ 保存しました")
        scope.launch {
            val added = repo().capture(t, sourceApp)
            if (added) NotificationHelper.refresh(ClipKeepApp.instance)
        }
    }

    /** 履歴の1件をクリップボードへ戻す。戻した内容は再記録しない。 */
    fun putToClipboard(context: Context, text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        lastSeen = text.trim()
        cm.setPrimaryClip(ClipData.newPlainText("ClipKeep", text))
    }
}
