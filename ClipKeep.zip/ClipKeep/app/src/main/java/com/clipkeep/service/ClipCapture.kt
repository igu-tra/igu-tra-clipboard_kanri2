package com.clipkeep.service

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.util.Log
import com.clipkeep.ClipKeepApp
import com.clipkeep.data.ClipRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * クリップボード読み取りの共通処理。
 *
 * Android 10 以降、getPrimaryClip() は
 *   1) 既定のIME（キーボード）であるアプリ
 *   2) 現在フォーカスを持っているアプリ
 * からしか成功しない。バックグラウンドからの読み取りは null が返る。
 *
 * そのため本アプリは複数の捕捉経路を用意して、どれかが通れば記録できるようにしている。
 *   - ClipAccessibilityService : 端末/ROMによっては常時読める（読めなければ静かに諦める）
 *   - QuickCaptureActivity     : 一瞬フォーカスを取って読む（確実に成功する）
 *   - ProcessTextActivity      : 文字選択メニューから直接テキストを受け取る（権限不要・確実）
 *   - ShareCaptureActivity     : 共有シートから受け取る（権限不要・確実）
 */
object ClipCapture {

    private const val TAG = "ClipCapture"
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var lastSeen: String? = null

    private fun repo(): ClipRepository = ClipKeepApp.instance.repo

    /** クリップボードから読み取って保存を試みる。成功したら本文を返す。 */
    fun captureFromClipboard(context: Context, onDone: ((String?) -> Unit)? = null) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = try {
            readText(cm)
        } catch (e: SecurityException) {
            Log.w(TAG, "clipboard read denied", e)
            null
        }
        if (text.isNullOrBlank()) {
            onDone?.invoke(null)
            return
        }
        save(text, sourceApp = null)
        onDone?.invoke(text)
    }

    private fun readText(cm: ClipboardManager): String? {
        if (!cm.hasPrimaryClip()) return null
        val clip: ClipData = cm.primaryClip ?: return null
        val sb = StringBuilder()
        for (i in 0 until clip.itemCount) {
            val t = clip.getItemAt(i).coerceToText(ClipKeepApp.instance)
            if (!t.isNullOrEmpty()) {
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(t)
            }
        }
        return sb.toString().ifBlank { null }
    }

    /** 任意のテキストを履歴に保存する（PROCESS_TEXT / 共有シート経由）。 */
    fun save(text: String, sourceApp: String?) {
        val t = text.trim()
        if (t.isEmpty() || t == lastSeen) return
        lastSeen = t
        scope.launch {
            val added = repo().capture(t, sourceApp)
            if (added) NotificationHelper.refresh(ClipKeepApp.instance)
        }
    }

    /** 履歴の1件をクリップボードへ戻す。 */
    fun putToClipboard(context: Context, text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        lastSeen = text.trim()
        cm.setPrimaryClip(ClipData.newPlainText("ClipKeep", text))
    }
}
