package com.clipkeep

import android.app.Application
import com.clipkeep.data.ClipRepository

class ClipKeepApp : Application() {
    val repo: ClipRepository by lazy { ClipRepository(this) }

    companion object {
        lateinit var instance: ClipKeepApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}

val app: ClipKeepApp get() = ClipKeepApp.instance
