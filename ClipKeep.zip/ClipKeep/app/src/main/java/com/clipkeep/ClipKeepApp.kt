package com.clipkeep

import android.app.Application
import android.os.Build
import com.clipkeep.data.ClipRepository
import com.clipkeep.service.ClipForegroundService
import com.clipkeep.service.ShizukuClipboard
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku

class ClipKeepApp : Application() {
    val repo: ClipRepository by lazy { ClipRepository(this) }

    companion object {
        lateinit var instance: ClipKeepApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // android.content.IClipboard は非SDKインターフェースなので、
        // リフレクションで触れるように制限を解除しておく。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            runCatching { HiddenApiBypass.addHiddenApiExemptions("") }
        }

        // Shizuku のバインダはプロセス起動より後に非同期で届く。
        // 届いた時点でキャッシュを捨て、監視サービスを立て直す。
        runCatching {
            Shizuku.addBinderReceivedListenerSticky {
                ShizukuClipboard.reset()
                // ここは多くの場合バックグラウンド。stop してしまうと Android 12+ の
                // 制限で起動し直せなくなるので、start だけ呼んで再武装させる。
                ClipForegroundService.start(this)
            }
            Shizuku.addBinderDeadListener {
                ShizukuClipboard.reset()
            }
        }
    }
}

val app: ClipKeepApp get() = ClipKeepApp.instance
