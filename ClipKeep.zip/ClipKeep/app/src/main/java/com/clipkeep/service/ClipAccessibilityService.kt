package com.clipkeep.service

import android.accessibilityservice.AccessibilityService
import android.content.ClipboardManager
import android.content.Context
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.clipkeep.data.Settings

/**
 * 「コピーされた瞬間」を見つけて自動保存する。
 *
 * クリップボードそのものはバックグラウンドから読めないので、代わりに
 *   1. コピー操作が行われたことを検知し
 *   2. FocusGrabber に読み取りを依頼する（一瞬だけフォーカスを取って読む）
 * という二段構えにしている。
 *
 * 検知は次の2つ。
 *   - 「コピー」と書かれたボタンが押された（文字選択メニュー、アプリ内のコピーボタン）
 *   - システムがクリップボードの通知やプレビューを出した（Android 13+ の挙動）
 *
 * 文字入力中の選択変化では発火しない。毎キーストロークでフォーカスを触ると邪魔になるため。
 */
class ClipAccessibilityService : AccessibilityService() {

    private lateinit var cm: ClipboardManager
    private var listener: ClipboardManager.OnPrimaryClipChangedListener? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

        // 端末によってはこのコールバックだけで読める。読めなくても害はない。
        listener = ClipboardManager.OnPrimaryClipChangedListener {
            onCopyDetected("clip-changed")
        }.also { runCatching { cm.addPrimaryClipChangedListener(it) } }

        ClipForegroundService.start(this)
        Log.i(TAG, "accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (!Settings(this).copyDetectionEnabled) return

        when (e.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED ->
                if (looksLikeCopyAction(e)) onCopyDetected("copy-button")

            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ->
                if (looksLikeSystemClipboardUi(e)) onCopyDetected("system-clipboard-ui")
        }
    }

    private fun onCopyDetected(reason: String) {
        Log.d(TAG, "copy detected ($reason)")
        FocusGrabber.request(this)
    }

    /** 押されたボタンの見た目の文字が「コピー」系かどうか。 */
    private fun looksLikeCopyAction(e: AccessibilityEvent): Boolean {
        val label = buildString {
            e.text.forEach { if (it != null) append(it).append(' ') }
            e.contentDescription?.let { append(it) }
        }.lowercase()
        if (label.isBlank()) return false
        return COPY_WORDS.any { label.contains(it) }
    }

    /** Android 13+ のクリップボードプレビューなど、システムUIの出現を手がかりにする。 */
    private fun looksLikeSystemClipboardUi(e: AccessibilityEvent): Boolean {
        val pkg = e.packageName?.toString() ?: return false
        if (pkg != "com.android.systemui" && !pkg.endsWith(".systemui")) return false
        val cls = e.className?.toString()?.lowercase() ?: ""
        if (cls.contains("clipboard")) return true
        val label = buildString {
            e.text.forEach { if (it != null) append(it).append(' ') }
        }.lowercase()
        return CLIPBOARD_WORDS.any { label.contains(it) }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        listener?.let { runCatching { cm.removePrimaryClipChangedListener(it) } }
        listener = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "ClipA11y"

        private val COPY_WORDS = listOf(
            "コピー", "copy", "複製", "クリップボードに", "copy link", "copy text"
        )
        private val CLIPBOARD_WORDS = listOf(
            "クリップボード", "clipboard", "コピーしました", "copied"
        )

        fun isEnabled(context: Context): Boolean {
            val enabled = android.provider.Settings.Secure.getString(
                context.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val me = "${context.packageName}/${ClipAccessibilityService::class.java.name}"
            val meShort = "${context.packageName}/.service.ClipAccessibilityService"
            return enabled.split(':').any { it.equals(me, true) || it.equals(meShort, true) }
        }
    }
}
