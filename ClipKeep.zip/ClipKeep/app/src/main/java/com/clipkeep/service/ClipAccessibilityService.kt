package com.clipkeep.service

import android.accessibilityservice.AccessibilityService
import android.content.ClipboardManager
import android.content.Context
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.clipkeep.data.Settings

/**
 * 「コピーされた瞬間」を見つけて自動保存する。
 *
 * クリップボードそのものはバックグラウンドから読めないので、
 *   1. コピー操作が行われたらしいことを検知し
 *   2. FocusGrabber に読み取りを依頼する（一瞬だけフォーカスを取って読む）
 * という二段構えにしている。
 *
 * 検知できる手がかりは端末やアプリによってばらつくので、複数の合図を見ている。
 * 何が届いているかは設定画面の「診断ログ」で確認できる。
 *
 * 重要: 文字選択の変化（TYPE_VIEW_TEXT_SELECTION_CHANGED）は手がかりに使わない。
 * このイベントは1文字入力するたびに飛んでくるので、これを合図にすると
 * 打鍵のたびにフォーカスを奪ってしまい、キーボードの操作が壊れる。
 */
class ClipAccessibilityService : AccessibilityService() {

    private lateinit var cm: ClipboardManager
    private var listener: ClipboardManager.OnPrimaryClipChangedListener? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

        listener = ClipboardManager.OnPrimaryClipChangedListener {
            Diag.log("クリップボード変化の通知を受信")
            onCopyDetected("clip-changed")
        }.also { runCatching { cm.addPrimaryClipChangedListener(it) } }

        ClipForegroundService.start(this)
        Diag.log("アクセシビリティ接続 OK")
        Log.i(TAG, "accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val settings = Settings(this)

        val type = e.eventType
        val pkg = e.packageName?.toString() ?: "-"

        // 自分が出した画面変化に反応すると、透明アクティビティが延々と起動し続ける
        if (pkg == packageName) return

        if (!settings.copyDetectionEnabled) return

        val label = labelOf(e)

        Diag.log("event ${AccessibilityEvent.eventTypeToString(type)} pkg=$pkg text=${Diag.short(label)}")

        when (type) {
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> {
                if (looksLikeCopyWord(label)) onCopyDetected("コピーボタン: ${Diag.short(label, 20)}")
            }

            AccessibilityEvent.TYPE_ANNOUNCEMENT,
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                // 「コピーしました」の読み上げやトーストを手がかりにする
                if (looksLikeCopiedMessage(label)) onCopyDetected("コピー完了の通知")
            }

            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                when {
                    isSystemClipboardUi(pkg, e.className?.toString(), label) ->
                        onCopyDetected("システムのクリップボード表示")

                    settings.checkOnAppSwitch -> onCopyDetected("アプリ切り替え")
                }
            }
        }
    }

    private fun onCopyDetected(reason: String) {
        Diag.log("→ 検知: $reason")
        FocusGrabber.request(this)
    }

    private fun labelOf(e: AccessibilityEvent): String {
        val sb = StringBuilder()
        runCatching { e.text.forEach { if (it != null) sb.append(it).append(' ') } }
        runCatching { e.contentDescription?.let { sb.append(it) } }
        return sb.toString().trim()
    }

    private fun looksLikeCopyWord(label: String): Boolean {
        if (label.isBlank()) return false
        val l = label.lowercase()
        return COPY_WORDS.any { l.contains(it) }
    }

    private fun looksLikeCopiedMessage(label: String): Boolean {
        if (label.isBlank()) return false
        val l = label.lowercase()
        return COPIED_WORDS.any { l.contains(it) }
    }

    private fun isSystemClipboardUi(pkg: String, cls: String?, label: String): Boolean {
        val fromSystem = pkg == "com.android.systemui" || pkg.endsWith(".systemui")
        if (fromSystem && (cls?.lowercase()?.contains("clipboard") == true)) return true
        if (fromSystem && looksLikeCopiedMessage(label)) return true
        return false
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        Diag.log("アクセシビリティ切断")
        listener?.let { runCatching { cm.removePrimaryClipChangedListener(it) } }
        listener = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "ClipA11y"

        private val COPY_WORDS = listOf(
            "コピー", "copy", "複製", "クリップボード", "clipboard", "コピ", "copiar", "복사"
        )
        private val COPIED_WORDS = listOf(
            "コピーしました", "にコピー", "copied", "クリップボードに", "copied to clipboard"
        )

        fun isEnabled(context: Context): Boolean {
            val enabled = android.provider.Settings.Secure.getString(
                context.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val me = "${context.packageName}/${ClipAccessibilityService::class.java.name}"
            val meShort = "${context.packageName}/.service.ClipAccessibilityService"
            return enabled.split(':').any { it.equals(me, true) || it.equals(meShort, true) }
        }
    }
}
