package com.clipkeep.service

import android.accessibilityservice.AccessibilityService
import android.content.ClipboardManager
import android.content.Context
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * クリップボードの変化を検知して自動記録する。
 *
 * 注意: Android 10 以降、この読み取りが成功するかは端末・OSバージョン・OEMの実装に依存する。
 * 読めなかった場合は例外を握りつぶして静かに諦め、他の捕捉経路（通知の「今のコピーを保存」ボタン、
 * 文字選択メニューの「ClipKeepに保存」）に任せる設計になっている。
 */
class ClipAccessibilityService : AccessibilityService() {

    private lateinit var cm: ClipboardManager
    private var listener: ClipboardManager.OnPrimaryClipChangedListener? = null
    private var lastAttemptAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        listener = ClipboardManager.OnPrimaryClipChangedListener { tryCapture("clip-changed") }
            .also { cm.addPrimaryClipChangedListener(it) }

        // 常駐通知を確実に立ち上げる
        ClipForegroundService.start(this)
        Log.i(TAG, "accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        // 文字選択が変わった直後はコピー操作の可能性が高いので、ワンテンポ置いて読みにいく
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED) {
            val now = System.currentTimeMillis()
            if (now - lastAttemptAt > 400) {
                lastAttemptAt = now
                tryCapture("selection")
            }
        }
    }

    private fun tryCapture(reason: String) {
        try {
            ClipCapture.captureFromClipboard(this) { text ->
                if (text == null) Log.d(TAG, "no clipboard access ($reason)")
            }
        } catch (t: Throwable) {
            Log.d(TAG, "capture failed ($reason): ${t.message}")
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        listener?.let { runCatching { cm.removePrimaryClipChangedListener(it) } }
        listener = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "ClipA11y"

        fun isEnabled(context: Context): Boolean {
            val enabled = android.provider.Settings.Secure.getString(
                context.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val me = "${context.packageName}/${ClipAccessibilityService::class.java.name}"
            val meShort = "${context.packageName}/.service.ClipAccessibilityService"
            return enabled.split(':').any { it.equals(me, true) || it.equals(meShort, true) }
        }
    }
}
