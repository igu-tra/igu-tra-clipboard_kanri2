package com.clipkeep.ui

import android.content.Intent
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clipkeep.service.ClipAccessibilityService
import com.clipkeep.service.ClipForegroundService
import com.clipkeep.service.NotificationHelper

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val count by vm.historyCount.collectAsStateWithLifecycle()

    var limitText by remember { mutableStateOf(vm.settings.rawHistoryLimit.toString()) }
    var notif by remember { mutableStateOf(vm.settings.notificationEnabled) }
    var confirmClear by remember { mutableStateOf(false) }
    var a11yOn by remember { mutableStateOf(ClipAccessibilityService.isEnabled(context)) }

    LaunchedEffect(Unit) {
        vm.refreshCount()
        a11yOn = ClipAccessibilityService.isEnabled(context)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("記録", style = MaterialTheme.typography.titleMedium)

        OutlinedTextField(
            value = limitText,
            onValueChange = { s ->
                limitText = s.filter { it.isDigit() }.take(6)
                limitText.toIntOrNull()?.let { vm.settings.historyLimit = it }
            },
            label = { Text("履歴の保持件数（0で無制限）") },
            supportingText = { Text("現在 $count 件保存中。定型文はこの数に含まれず、絶対に自動削除されません。") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        HorizontalDivider()
        Text("捕捉の方法", style = MaterialTheme.typography.titleMedium)

        SettingRow(
            title = "アクセシビリティ監視",
            subtitle = if (a11yOn)
                "オン。コピー操作を自動で記録しようとします（端末によっては読み取りがOSに拒否されます）。"
            else
                "オフ。オンにするとコピーの自動記録を試みます。",
            action = {
                TextButton(onClick = {
                    context.startActivity(
                        Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text(if (a11yOn) "設定" else "オンにする") }
            }
        )

        SettingRow(
            title = "常駐通知",
            subtitle = "通知の「今のコピーを保存」ボタンは、どの端末でも確実にクリップボードを読めます。",
            action = {
                Switch(checked = notif, onCheckedChange = {
                    notif = it
                    vm.settings.notificationEnabled = it
                    if (it) ClipForegroundService.start(context) else ClipForegroundService.stop(context)
                })
            }
        )

        SettingRow(
            title = "文字選択メニュー",
            subtitle = "文字を長押し →「ClipKeepに保存」で、コピーせずに直接記録できます。設定不要で常に使えます。",
            action = {}
        )

        HorizontalDivider()
        Text("データ", style = MaterialTheme.typography.titleMedium)

        OutlinedButton(
            onClick = { confirmClear = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("履歴をすべて削除（定型文は残る）") }

        Spacer(Modifier.height(24.dp))
        Text(
            "Android 10 以降、アプリがバックグラウンドでクリップボードを読むことはOSが制限しています。" +
                "本アプリは複数の入口を用意しているので、自動記録が効かない端末でも通知ボタンや文字選択メニューから記録できます。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "履歴を全削除",
            message = "定型文（ピン留め）は削除されません。",
            onDismiss = { confirmClear = false },
            onConfirm = {
                vm.clearHistory()
                NotificationHelper.refresh(context)
                confirmClear = false
            }
        )
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, action: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(8.dp))
        action()
    }
}
