package com.clipkeep.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clipkeep.service.ClipAccessibilityService
import com.clipkeep.service.ClipForegroundService
import com.clipkeep.service.NotificationHelper
import com.clipkeep.service.ShizukuClipboard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private const val SHIZUKU_PACKAGE = ShizukuClipboard.SHIZUKU_PACKAGE
private const val MIN_LIMIT = 20

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val count by vm.historyCount.collectAsStateWithLifecycle()

    var savedLimit by remember { mutableIntStateOf(vm.settings.rawHistoryLimit) }
    var limitText by remember { mutableStateOf(savedLimit.toString()) }
    val limitPending = limitText != savedLimit.toString() && limitText.isNotEmpty()
    var notif by remember { mutableStateOf(vm.settings.notificationEnabled) }
    var auto by remember { mutableStateOf(vm.settings.autoCaptureEnabled) }
    var interval by remember { mutableLongStateOf(vm.settings.pollIntervalMs) }
    var confirmClear by remember { mutableStateOf(false) }
    var a11yOn by remember { mutableStateOf(false) }
    var shizuku by remember { mutableStateOf(ShizukuClipboard.State.NOT_INSTALLED) }

    // Shizuku は外部アプリなので、開いている間は状態を見張る。
    // バインダ越しの問い合わせなのでメインスレッドでは行わない。
    LaunchedEffect(Unit) {
        vm.refreshCount()
        while (true) {
            val next = withContext(Dispatchers.IO) {
                ShizukuClipboard.state(context) to ClipAccessibilityService.isEnabled(context)
            }
            shizuku = next.first
            a11yOn = next.second
            delay(1500)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // ------------- 自動監視 -------------
        Text("自動監視", style = MaterialTheme.typography.titleMedium)

        ShizukuCard(
            state = shizuku,
            onInstall = {
                runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$SHIZUKU_PACKAGE"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }.onFailure {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            },
            onOpen = {
                runCatching {
                    context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
                        ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        ?.let { context.startActivity(it) }
                }
            },
            onGrant = { ShizukuClipboard.requestPermission(MainActivity.SHIZUKU_REQUEST_CODE) }
        )

        SettingRow(
            title = "コピーを自動で記録する",
            subtitle = if (shizuku == ShizukuClipboard.State.READY)
                "動作中。コピーするだけで履歴に入ります。"
            else
                "Shizukuが使える状態になると有効になります。",
            action = {
                Switch(checked = auto, onCheckedChange = {
                    auto = it
                    vm.settings.autoCaptureEnabled = it
                    ClipForegroundService.restart(context)
                })
            }
        )

        if (auto) {
            Text("チェックの間隔", style = MaterialTheme.typography.bodyMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                listOf(500L to "0.5秒", 1000L to "1秒", 2000L to "2秒").forEach { (ms, label) ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        RadioButton(
                            selected = interval == ms,
                            onClick = {
                                interval = ms
                                vm.settings.pollIntervalMs = ms
                                ClipForegroundService.restart(context)
                            }
                        )
                        Text(label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            Text(
                "短いほど反応が速く、長いほど電池に優しくなります。画面が消えている間は止まります。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        HorizontalDivider()

        // ------------- 記録 -------------
        Text("記録", style = MaterialTheme.typography.titleMedium)

        OutlinedTextField(
            value = limitText,
            onValueChange = { s -> limitText = s.filter { it.isDigit() }.take(6) },
            label = { Text("履歴の保持件数（0で無制限）") },
            supportingText = {
                Text(
                    if (limitPending) "「保存」を押すと反映されます。"
                    else "現在 $count 件。定型文はこの数に含まれず、自動削除されません。"
                )
            },
            singleLine = true,
            trailingIcon = {
                if (limitPending) {
                    TextButton(onClick = {
                        limitText.toIntOrNull()?.let {
                            val v = if (it == 0) 0 else it.coerceAtLeast(MIN_LIMIT)
                            vm.settings.historyLimit = v
                            limitText = v.toString()
                            savedLimit = v
                        }
                    }) { Text("保存") }
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
        if (limitPending && (limitText.toIntOrNull() ?: 0).let { it in 1 until MIN_LIMIT }) {
            Text(
                "誤操作で履歴が消えないよう、$MIN_LIMIT 件未満は指定できません（0なら無制限）。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }

        HorizontalDivider()

        // ------------- 手動の入口 -------------
        Text("手動の入口（自動が効かないとき用）", style = MaterialTheme.typography.titleMedium)

        SettingRow(
            title = "常駐通知",
            subtitle = "通知の「今のコピーを保存」は、Shizukuが無くても確実に読めます。" +
                "自動監視が有効な間は、オフにしても最小限の通知だけは残ります（Androidの仕様）。",
            action = {
                Switch(checked = notif, onCheckedChange = {
                    notif = it
                    vm.settings.notificationEnabled = it
                    // 自動監視が有効ならサービスは生かしたままにする。
                    // restart 側の start() が「両方オフなら起動しない」を判断してくれる。
                    ClipForegroundService.restart(context)
                })
            }
        )

        SettingRow(
            title = "アクセシビリティ監視",
            subtitle = if (a11yOn) "オン。Shizukuが無い端末での補助として働きます。" else "オフ。",
            action = {
                TextButton(onClick = {
                    context.startActivity(
                        Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text(if (a11yOn) "設定" else "オンにする") }
            }
        )

        SettingRow(
            title = "文字選択メニュー",
            subtitle = "文字を長押し →「ClipKeepに保存」。設定不要で常に使えます。",
            action = {}
        )

        HorizontalDivider()

        // ------------- データ -------------
        Text("データ", style = MaterialTheme.typography.titleMedium)

        OutlinedButton(
            onClick = { confirmClear = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("履歴をすべて削除（定型文は残る）") }

        Spacer(Modifier.height(24.dp))
        Text(
            "同じ内容を再びコピーした場合、履歴は増えず古い方が消えて最新の1件だけが残ります。" +
                "定型文に同じ本文を追加しようとしたときは警告が出ます。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "履歴を全削除",
            message = "定型文（ピン留め）は削除されません。",
            onDismiss = { confirmClear = false },
            onConfirm = {
                vm.clearHistory()
                NotificationHelper.refresh(context)
                confirmClear = false
            }
        )
    }
}

@Composable
private fun ShizukuCard(
    state: ShizukuClipboard.State,
    onInstall: () -> Unit,
    onOpen: () -> Unit,
    onGrant: () -> Unit
) {
    val (title, body, button, action) = when (state) {
        ShizukuClipboard.State.READY -> Quad(
            "Shizuku: 接続済み",
            "バックグラウンドでもクリップボードを読める状態です。",
            null, null
        )
        ShizukuClipboard.State.PERMISSION_REQUIRED -> Quad(
            "Shizuku: 許可待ち",
            "ClipKeepにShizukuの使用を許可してください。",
            "許可する", onGrant
        )
        ShizukuClipboard.State.NOT_RUNNING -> Quad(
            "Shizuku: 停止中",
            "端末を再起動するとShizukuは止まります。Shizukuアプリを開き、" +
                "「ワイヤレスデバッグから起動」を実行してください（PCは不要です）。",
            "Shizukuを開く", onOpen
        )
        ShizukuClipboard.State.NOT_INSTALLED -> Quad(
            "Shizuku: 未インストール",
            "自動記録にはShizukuが必要です。インストールして初回セットアップを済ませてください。",
            "入手する", onInstall
        )
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                color = if (state == ShizukuClipboard.State.READY)
                    MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
            Text(body, style = MaterialTheme.typography.bodySmall)
            if (button != null && action != null) {
                Button(onClick = action) { Text(button) }
            }
        }
    }
}

private data class Quad(
    val a: String,
    val b: String,
    val c: String?,
    val d: (() -> Unit)?
)

@Composable
private fun SettingRow(title: String, subtitle: String, action: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(8.dp))
        action()
    }
}
