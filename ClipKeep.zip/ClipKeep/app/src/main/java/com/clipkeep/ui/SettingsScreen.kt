package com.clipkeep.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clipkeep.service.ClipAccessibilityService
import com.clipkeep.service.ClipForegroundService
import com.clipkeep.service.FocusGrabber
import com.clipkeep.service.NotificationHelper
import com.clipkeep.service.ShizukuClipboard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private const val SHIZUKU_PACKAGE = ShizukuClipboard.SHIZUKU_PACKAGE
private const val MIN_LIMIT = 20

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val count by vm.historyCount.collectAsStateWithLifecycle()

    var savedLimit by remember { mutableIntStateOf(vm.settings.rawHistoryLimit) }
    var limitText by remember { mutableStateOf(savedLimit.toString()) }
    val limitPending = limitText != savedLimit.toString() && limitText.isNotEmpty()

    var notif by remember { mutableStateOf(vm.settings.notificationEnabled) }
    var detect by remember { mutableStateOf(vm.settings.copyDetectionEnabled) }
    var auto by remember { mutableStateOf(vm.settings.autoCaptureEnabled) }
    var interval by remember { mutableLongStateOf(vm.settings.pollIntervalMs) }
    var confirmClear by remember { mutableStateOf(false) }

    var a11yOn by remember { mutableStateOf(false) }
    var overlayOn by remember { mutableStateOf(false) }
    var shizuku by remember { mutableStateOf(ShizukuClipboard.State.NOT_INSTALLED) }

    // 外部の設定は画面外で変わるので、開いている間は見張る（バインダ越しなのでIOスレッドで）
    LaunchedEffect(Unit) {
        vm.refreshCount()
        while (true) {
            val snapshot = withContext(Dispatchers.IO) {
                Triple(
                    ClipAccessibilityService.isEnabled(context),
                    FocusGrabber.canDrawOverlays(context),
                    ShizukuClipboard.state(context)
                )
            }
            a11yOn = snapshot.first
            overlayOn = snapshot.second
            shizuku = snapshot.third
            delay(1500)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        // ===================== 自動記録 =====================
        Text("自動記録", style = MaterialTheme.typography.titleMedium)

        StatusCard(
            ok = a11yOn,
            title = if (a11yOn) "コピー検知: 有効" else "コピー検知: 無効",
            body = if (a11yOn)
                "「コピー」が押された瞬間を見つけて、その一瞬だけフォーカスを借りて内容を読み取ります。" +
                    "Wi-Fiも外部アプリも不要で、端末を再起動しても自動で復帰します。"
            else
                "これが自動記録の本体です。アクセシビリティでClipKeepを有効にしてください。",
            button = if (a11yOn) "設定を開く" else "有効にする",
            onClick = {
                context.startActivity(
                    Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        )

        if (a11yOn) {
            SettingRow(
                title = "コピーを検知して保存",
                subtitle = "オフにすると自動記録を止め、手動の入口だけになります。",
                action = {
                    Switch(checked = detect, onCheckedChange = {
                        detect = it
                        vm.settings.copyDetectionEnabled = it
                    })
                }
            )
        }

        if (!overlayOn) {
            StatusCard(
                ok = false,
                title = "重ねて表示: 未許可（推奨）",
                body = "アクセシビリティ経由で読めない端末があります。この許可があると予備の経路が使えるようになり、" +
                    "自動記録が成功しやすくなります。画面に何かを表示するためではありません。",
                button = "許可する",
                onClick = {
                    runCatching {
                        context.startActivity(
                            Intent(
                                AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            )
        }

        HorizontalDivider()

        // ===================== Shizuku（任意） =====================
        Text("Shizuku（任意・上位の経路）", style = MaterialTheme.typography.titleMedium)
        Text(
            "Shizukuが動いている間は、フォーカスを触らずに直接クリップボードを読めます。" +
                "ただしAndroidの仕様上、Wi-Fiが切れるとワイヤレスデバッグごと止まります。" +
                "自宅では使う、外では上のコピー検知に任せる、という使い分けができます。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        ShizukuCard(
            state = shizuku,
            onInstall = {
                runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$SHIZUKU_PACKAGE"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }.onFailure {
                    runCatching {
                        context.startActivity(
                            Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse("https://github.com/RikkaApps/Shizuku/releases")
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            },
            onOpen = {
                runCatching {
                    context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
                        ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        ?.let { context.startActivity(it) }
                }
            },
            onGrant = { ShizukuClipboard.requestPermission(MainActivity.SHIZUKU_REQUEST_CODE) }
        )

        SettingRow(
            title = "Shizukuで常時監視する",
            subtitle = "Shizukuが接続済みのときだけ働きます。",
            action = {
                Switch(checked = auto, onCheckedChange = {
                    auto = it
                    vm.settings.autoCaptureEnabled = it
                    ClipForegroundService.restart(context)
                })
            }
        )

        if (auto && shizuku == ShizukuClipboard.State.READY) {
            Text("チェックの間隔", style = MaterialTheme.typography.bodyMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                listOf(500L to "0.5秒", 1000L to "1秒", 2000L to "2秒").forEach { (ms, label) ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        RadioButton(
                            selected = interval == ms,
                            onClick = {
                                interval = ms
                                vm.settings.pollIntervalMs = ms
                                ClipForegroundService.restart(context)
                            }
                        )
                        Text(label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        HorizontalDivider()

        // ===================== 記録 =====================
        Text("記録", style = MaterialTheme.typography.titleMedium)

        OutlinedTextField(
            value = limitText,
            onValueChange = { s -> limitText = s.filter { it.isDigit() }.take(6) },
            label = { Text("履歴の保持件数（0で無制限）") },
            supportingText = {
                Text(
                    if (limitPending) "「保存」を押すと反映されます。"
                    else "現在 $count 件。定型文はこの数に含まれず、自動削除されません。"
                )
            },
            singleLine = true,
            trailingIcon = {
                if (limitPending) {
                    TextButton(onClick = {
                        limitText.toIntOrNull()?.let {
                            val v = if (it == 0) 0 else it.coerceAtLeast(MIN_LIMIT)
                            vm.settings.historyLimit = v
                            limitText = v.toString()
                            savedLimit = v
                        }
                    }) { Text("保存") }
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
        if (limitPending && (limitText.toIntOrNull() ?: 0).let { it in 1 until MIN_LIMIT }) {
            Text(
                "誤操作で履歴が消えないよう、$MIN_LIMIT 件未満は指定できません（0なら無制限）。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }

        HorizontalDivider()

        // ===================== 手動の入口 =====================
        Text("手動の入口", style = MaterialTheme.typography.titleMedium)

        SettingRow(
            title = "常駐通知",
            subtitle = "「今のコピーを保存」ボタンはどんな状況でも確実に読めます。" +
                "自動記録が有効な間は、オフにしても最小限の通知だけは残ります（Androidの仕様）。",
            action = {
                Switch(checked = notif, onCheckedChange = {
                    notif = it
                    vm.settings.notificationEnabled = it
                    ClipForegroundService.restart(context)
                })
            }
        )

        SettingRow(
            title = "文字選択メニュー",
            subtitle = "文字を長押し →「ClipKeepに保存」。設定不要で常に使えます。",
            action = {}
        )

        HorizontalDivider()

        // ===================== データ =====================
        Text("データ", style = MaterialTheme.typography.titleMedium)

        OutlinedButton(
            onClick = { confirmClear = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("履歴をすべて削除（定型文は残る）") }

        Spacer(Modifier.height(24.dp))
        Text(
            "同じ内容を再びコピーした場合、履歴は増えず古い方が消えて最新の1件だけが残ります。" +
                "定型文に同じ本文を追加しようとしたときは警告が出ます。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "履歴を全削除",
            message = "定型文（ピン留め）は削除されません。",
            onDismiss = { confirmClear = false },
            onConfirm = {
                vm.clearHistory()
                NotificationHelper.refresh(context)
                confirmClear = false
            }
        )
    }
}

@Composable
private fun StatusCard(
    ok: Boolean,
    title: String,
    body: String,
    button: String?,
    onClick: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
            Text(body, style = MaterialTheme.typography.bodySmall)
            if (button != null) {
                Button(onClick = onClick) { Text(button) }
            }
        }
    }
}

@Composable
private fun ShizukuCard(
    state: ShizukuClipboard.State,
    onInstall: () -> Unit,
    onOpen: () -> Unit,
    onGrant: () -> Unit
) = when (state) {
    ShizukuClipboard.State.READY -> StatusCard(
        ok = true,
        title = "Shizuku: 接続済み",
        body = "フォーカスを触らずにクリップボードを読める状態です。",
        button = null,
        onClick = {}
    )
    ShizukuClipboard.State.PERMISSION_REQUIRED -> StatusCard(
        ok = false,
        title = "Shizuku: 許可待ち",
        body = "ClipKeepにShizukuの使用を許可してください。",
        button = "許可する",
        onClick = onGrant
    )
    ShizukuClipboard.State.NOT_RUNNING -> StatusCard(
        ok = false,
        title = "Shizuku: 停止中",
        body = "Wi-Fiが切れたり端末を再起動すると停止します。使いたいときはShizukuアプリを開いて" +
            "「ワイヤレスデバッグから起動」の開始を押してください。停止したままでもコピー検知は動きます。",
        button = "Shizukuを開く",
        onClick = onOpen
    )
    ShizukuClipboard.State.NOT_INSTALLED -> StatusCard(
        ok = false,
        title = "Shizuku: 未インストール",
        body = "なくても構いません。入れると自宅Wi-Fi環境でより確実に読めるようになります。" +
            "PlayストアのShizukuは古いので、GitHubのReleasesから入れてください。",
        button = "入手する",
        onClick = onInstall
    )
}

@Composable
private fun SettingRow(title: String, subtitle: String, action: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(8.dp))
        action()
    }
}
