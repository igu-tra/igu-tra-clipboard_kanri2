package com.clipkeep.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.clipkeep.ClipKeepApp
import com.clipkeep.data.Category
import com.clipkeep.data.ClipEntry
import com.clipkeep.data.Settings
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class MainViewModel : ViewModel() {

    private val repo = ClipKeepApp.instance.repo
    val settings = Settings(ClipKeepApp.instance)

    val query = MutableStateFlow("")

    val history: StateFlow<List<ClipEntry>> =
        query.debounce(120).flatMapLatest { repo.history(it) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<Category>> =
        repo.categories().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val snippets: StateFlow<List<ClipEntry>> =
        repo.allSnippets().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** null = すべて, -1 = 未分類, それ以外 = categoryId */
    val selectedTab = MutableStateFlow<Long?>(null)

    val visibleSnippets: StateFlow<List<ClipEntry>> =
        combine(snippets, selectedTab) { list, tab ->
            when (tab) {
                null -> list
                UNCATEGORIZED -> list.filter { it.categoryId == null }
                else -> list.filter { it.categoryId == tab }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val historyCount = MutableStateFlow(0)

    init { refreshCount() }

    fun refreshCount() = viewModelScope.launch { historyCount.value = repo.historyCount() }

    fun delete(e: ClipEntry) = viewModelScope.launch { repo.delete(e.id); refreshCount() }
    fun clearHistory() = viewModelScope.launch { repo.clearHistory(); refreshCount() }
    fun update(e: ClipEntry) = viewModelScope.launch { repo.update(e) }
    fun pin(e: ClipEntry, categoryId: Long?) = viewModelScope.launch { repo.pin(e.id, categoryId); refreshCount() }
    fun unpin(e: ClipEntry) = viewModelScope.launch { repo.unpin(e.id); refreshCount() }

    fun addSnippet(text: String, title: String?, categoryId: Long?) =
        viewModelScope.launch { repo.addSnippet(text, title, categoryId) }

    /**
     * 定型文を追加する。同じ本文が既にあれば追加せず onDuplicate を呼ぶ。
     * 呼び出し側で「それでも追加」を選んだら addSnippet を直接呼ぶ。
     */
    fun addSnippetChecked(
        text: String,
        title: String?,
        categoryId: Long?,
        onDuplicate: (ClipEntry) -> Unit
    ) = viewModelScope.launch {
        val dup = repo.findDuplicateSnippet(text)
        if (dup != null) onDuplicate(dup) else repo.addSnippet(text, title, categoryId)
    }

    /** 履歴を定型文に昇格させる。重複していれば警告を返す。 */
    fun pinChecked(e: ClipEntry, categoryId: Long?, onDuplicate: (ClipEntry) -> Unit) =
        viewModelScope.launch {
            val dup = repo.findDuplicateSnippet(e.text, excludeId = e.id)
            if (dup != null) onDuplicate(dup) else { repo.pin(e.id, categoryId); refreshCount() }
        }

    fun addCategory(name: String) = viewModelScope.launch { repo.addCategory(name) }
    fun renameCategory(c: Category, name: String) = viewModelScope.launch { repo.renameCategory(c, name) }
    fun deleteCategory(c: Category) = viewModelScope.launch {
        repo.deleteCategory(c.id)
        if (selectedTab.value == c.id) selectedTab.value = null
    }

    companion object {
        const val UNCATEGORIZED = -1L
    }
}
