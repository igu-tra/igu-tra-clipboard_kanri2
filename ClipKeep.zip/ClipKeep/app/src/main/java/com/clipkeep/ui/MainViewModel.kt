package com.clipkeep.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.clipkeep.ClipKeepApp
import com.clipkeep.data.Backup
import com.clipkeep.data.Category
import com.clipkeep.data.ClipEntry
import com.clipkeep.data.ClipRepository
import com.clipkeep.data.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class MainViewModel : ViewModel() {

    private val repo = ClipKeepApp.instance.repo
    val settings = Settings(ClipKeepApp.instance)

    val query = MutableStateFlow("")

    /** 履歴を手動で並び替えるモードかどうか */
    val manualOrder = MutableStateFlow(settings.historyManualOrder)

    val history: StateFlow<List<ClipEntry>> =
        combine(query.debounce(120), manualOrder) { q, m -> q to m }
            .flatMapLatest { (q, m) -> repo.history(q, m) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setManualOrder(on: Boolean) = viewModelScope.launch {
        settings.historyManualOrder = on
        // 手動に切り替えた瞬間、今見えている順番（新しい順）をそのまま固定する
        if (on) repo.normalizeHistoryOrder()
        manualOrder.value = on
    }

    /** 画面に並んでいる順をそのまま保存する。 */
    fun applyOrder(ids: List<Long>) = viewModelScope.launch { repo.applyOrder(ids) }

    val categories: StateFlow<List<Category>> =
        repo.categories().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val snippets: StateFlow<List<ClipEntry>> =
        repo.allSnippets().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** null = すべて, -1 = 未分類, それ以外 = categoryId */
    val selectedTab = MutableStateFlow<Long?>(null)

    val visibleSnippets: StateFlow<List<ClipEntry>> =
        combine(snippets, selectedTab) { list, tab ->
            when (tab) {
                null -> list
                UNCATEGORIZED -> list.filter { it.categoryId == null }
                else -> list.filter { it.categoryId == tab }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val historyCount = MutableStateFlow(0)

    init { refreshCount() }

    fun refreshCount() = viewModelScope.launch { historyCount.value = repo.historyCount() }

    fun delete(e: ClipEntry) = viewModelScope.launch { repo.delete(e.id); refreshCount() }
    fun clearHistory() = viewModelScope.launch { repo.clearHistory(); refreshCount() }
    fun update(e: ClipEntry) = viewModelScope.launch { repo.update(e) }
    fun pin(e: ClipEntry, categoryId: Long?) = viewModelScope.launch { repo.pin(e.id, categoryId); refreshCount() }
    fun unpin(e: ClipEntry) = viewModelScope.launch { repo.unpin(e.id); refreshCount() }

    fun addSnippet(text: String, title: String?, categoryId: Long?) =
        viewModelScope.launch { repo.addSnippet(text, title, categoryId) }

    /**
     * 定型文を追加する。同じ本文が既にあれば追加せず onDuplicate を呼ぶ。
     * 呼び出し側で「それでも追加」を選んだら addSnippet を直接呼ぶ。
     */
    fun addSnippetChecked(
        text: String,
        title: String?,
        categoryId: Long?,
        onDuplicate: (ClipEntry) -> Unit
    ) = viewModelScope.launch {
        val dup = repo.findDuplicateSnippet(text)
        if (dup != null) onDuplicate(dup) else repo.addSnippet(text, title, categoryId)
    }

    /** 履歴を定型文に昇格させる。重複していれば警告を返す。 */
    fun pinChecked(e: ClipEntry, categoryId: Long?, onDuplicate: (ClipEntry) -> Unit) =
        viewModelScope.launch {
            val dup = repo.findDuplicateSnippet(e.text, excludeId = e.id)
            if (dup != null) onDuplicate(dup) else { repo.pin(e.id, categoryId); refreshCount() }
        }

    fun addCategory(name: String) = viewModelScope.launch { repo.addCategory(name) }
    fun renameCategory(c: Category, name: String) = viewModelScope.launch { repo.renameCategory(c, name) }
    fun deleteCategory(c: Category) = viewModelScope.launch {
        repo.deleteCategory(c.id)
        if (selectedTab.value == c.id) selectedTab.value = null
    }

    // ==================== 書き出し・読み込み ====================

    fun exportTo(
        context: Context,
        uri: Uri,
        scope: ClipRepository.Scope,
        categoryId: Long?,
        asJson: Boolean,
        onDone: (String) -> Unit
    ) = viewModelScope.launch {
        val msg = withContext(Dispatchers.IO) {
            runCatching {
                val bundle = repo.buildBackup(scope, categoryId)
                val body = if (asJson) Backup.toJson(bundle) else Backup.toText(bundle)
                val out = context.contentResolver.openOutputStream(uri, "wt")
                    ?: error("ファイルを開けませんでした")
                out.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                "書き出しました（履歴 ${bundle.historyCount} 件 / 定型文 ${bundle.snippetCount} 件）"
            }.getOrElse { "書き出しに失敗しました: ${it.message}" }
        }
        onDone(msg)
    }

    fun importFrom(
        context: Context,
        uri: Uri,
        replace: Boolean,
        onDone: (String) -> Unit
    ) = viewModelScope.launch {
        val msg = withContext(Dispatchers.IO) {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)
                    ?.use { it.readBytes().toString(Charsets.UTF_8) }
                    ?: error("ファイルを開けませんでした")
                val bundle = Backup.parse(raw) ?: error("形式を読み取れませんでした")
                val r = repo.restore(bundle, replace)
                "取り込みました（追加 ${r.added} 件 / 重複スキップ ${r.skipped} 件 / 新しいタブ ${r.tabs} 個）"
            }.getOrElse { "取り込みに失敗しました: ${it.message}" }
        }
        refreshCount()
        onDone(msg)
    }

    companion object {
        const val UNCATEGORIZED = -1L
    }
}
