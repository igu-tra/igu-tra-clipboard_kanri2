package com.clipkeep.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * 定型文のタブ。履歴側では使わない。
 *
 * parentId が null ならメインタブ、入っていればそのメインのサブタブ。
 * メインタブは「定型文を直接持つ」か「サブタブを持つ」かのどちらか一方だけで、
 * 両方が混在することはない（サブを作った時点で直下の定型文はサブへ移る）。
 */
@Entity(tableName = "categories", indices = [Index("parentId")])
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val position: Int = 0,
    val parentId: Long? = null
)

/**
 * クリップ1件。
 * pinned = true のものが「定型文」扱いになり、自動削除の対象外・categoryId でタブ分けされる。
 */
@Entity(
    tableName = "clips",
    indices = [Index("createdAt"), Index("pinned"), Index("categoryId")]
)
data class ClipEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val title: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val pinned: Boolean = false,
    val categoryId: Long? = null,
    val position: Int = 0,
    val sourceApp: String? = null
) {
    val preview: String
        get() = text.replace('\n', ' ').trim().let { if (it.length > 140) it.take(140) + "…" else it }
}
