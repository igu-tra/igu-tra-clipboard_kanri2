package com.clipkeep.data

import android.content.Context
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

class ClipRepository(context: Context) {

    private val app = context.applicationContext
    private val db = ClipDatabase.get(app)
    private val clips = db.clipDao()
    private val cats = db.categoryDao()
    private val prefs = Settings(app)

    fun history(query: String, manualOrder: Boolean): Flow<List<ClipEntry>> = when {
        query.isBlank() && manualOrder -> clips.historyManual()
        query.isBlank() -> clips.history()
        manualOrder -> clips.searchHistoryManual(query.trim())
        else -> clips.searchHistory(query.trim())
    }

    fun categories(): Flow<List<Category>> = cats.all()
    fun allSnippets(): Flow<List<ClipEntry>> = clips.allSnippets()

    suspend fun recent(n: Int) = clips.recent(n)
    suspend fun byId(id: Long) = clips.byId(id)
    suspend fun historyCount() = clips.historyCount()

    /**
     * 捕捉したテキストを保存する。
     * 同じ本文が既に履歴にあれば新規追加せず、日時だけ更新して先頭に上げる。
     * 戻り値: 新しく記録されたら true（＝直前と同じ内容なら false）
     */
    suspend fun capture(text: String, sourceApp: String? = null): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        if (t.length > MAX_TEXT_LEN) return capture(t.take(MAX_TEXT_LEN), sourceApp)

        val existing = clips.findHistoryByText(t)
        val now = System.currentTimeMillis()
        if (existing != null) {
            // 完全一致の重複は増やさず、既存の1件を最新として上に上げる（＝古い方が消えるのと同じ）
            if (now - existing.createdAt < DEDUPE_WINDOW_MS) return false
            clips.update(existing.copy(createdAt = now, updatedAt = now, sourceApp = sourceApp ?: existing.sourceApp))
            clips.deleteHistoryDuplicates(t, existing.id)
            return true
        }
        // 手動並び替え中は、新しいコピーが必ず先頭に来るようにする
        val pos = if (prefs.historyManualOrder) (clips.minHistoryPosition() ?: 0) - 1 else 0
        val newId = clips.insert(
            ClipEntry(text = t, createdAt = now, updatedAt = now, sourceApp = sourceApp, position = pos)
        )
        clips.deleteHistoryDuplicates(t, newId)
        val limit = prefs.historyLimit
        if (clips.historyCount() > limit) clips.trimHistory(limit)
        return true
    }

    suspend fun delete(id: Long) = clips.deleteById(id)
    suspend fun clearHistory() = clips.clearHistory()
    suspend fun update(e: ClipEntry) = clips.update(e)

    /**
     * 履歴 -> 定型文へ昇格。
     * 履歴側の position（手動並び替え中は負の値になりうる）を持ち込むと
     * 定型文の並びが乱れるので、ここで振り直す。
     */
    suspend fun pin(id: Long, categoryId: Long?) {
        val e = clips.byId(id) ?: return
        clips.update(
            e.copy(
                pinned = true,
                categoryId = categoryId,
                position = 0,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    /** 定型文 -> 履歴へ戻す。手動並び替え中なら先頭に置く。 */
    suspend fun unpin(id: Long) {
        val e = clips.byId(id) ?: return
        val pos = if (prefs.historyManualOrder) (clips.minHistoryPosition() ?: 0) - 1 else 0
        clips.update(
            e.copy(
                pinned = false,
                categoryId = null,
                position = pos,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun addSnippet(text: String, title: String?, categoryId: Long?): Long =
        clips.insert(
            ClipEntry(
                text = text, title = title?.ifBlank { null },
                pinned = true, categoryId = categoryId
            )
        )

    /**
     * タブを追加する。parentId を渡すとサブタブになる。
     *
     * メインタブに初めてサブタブを作ったときは、そのメイン直下にあった定型文を
     * まるごと新しいサブタブへ移す。メインとサブに定型文が混在しないようにするため。
     */
    suspend fun addCategory(name: String, parentId: Long? = null): Long = db.withTransaction {
        val siblings = if (parentId == null) cats.rootsOnce() else cats.childrenOf(parentId)
        val id = cats.insert(Category(name = name, position = siblings.size, parentId = parentId))
        if (parentId != null && cats.childCount(parentId) == 1) {
            cats.moveClips(from = parentId, to = id)
        }
        id
    }

    suspend fun renameCategory(c: Category, name: String) = cats.update(c.copy(name = name))

    /**
     * タブを削除する。
     * ・サブを持つメイン → サブごと消し、中身はすべて未分類へ
     * ・最後のサブ       → 中身は親の直下へ戻す（一層に戻る）
     * ・それ以外のサブ   → 中身は未分類へ
     */
    suspend fun deleteCategory(id: Long) = db.withTransaction {
        val target = cats.byId(id) ?: return@withTransaction
        val children = cats.childrenOf(id)

        if (children.isNotEmpty()) {
            children.forEach { c ->
                cats.moveClips(c.id, null)
                cats.deleteById(c.id)
            }
            cats.moveClips(id, null)
        } else {
            val parentId = target.parentId
            if (parentId != null && cats.childCount(parentId) == 1) {
                cats.moveClips(id, parentId)
            } else {
                cats.moveClips(id, null)
            }
        }
        cats.deleteById(id)
    }

    /** そのタブがサブタブを持っているか（＝直下に定型文を置けないか）。 */
    suspend fun hasChildren(id: Long): Boolean = cats.childCount(id) > 0

    /** 同じ本文の定型文が既にあれば返す。追加前の警告用。 */
    suspend fun findDuplicateSnippet(text: String, excludeId: Long = -1L): ClipEntry? =
        clips.findSnippetByText(text.trim(), excludeId)

    // ==================== 並び順 ====================

    /** 画面に並んでいる順そのままを保存する。 */
    suspend fun applyOrder(ids: List<Long>) {
        if (ids.isEmpty()) return
        db.withTransaction {
            ids.forEachIndexed { i, id -> clips.updatePosition(id, i) }
        }
    }

    /** 手動並び替えを始めるときに、今の見え方（新しい順）をそのまま position に焼き込む。 */
    suspend fun normalizeHistoryOrder() {
        val ids = clips.historyIdsByTime()
        applyOrder(ids)
    }

    // ==================== 書き出し・読み込み ====================

    enum class Scope { ALL, HISTORY, SNIPPETS, ONE_TAB }

    suspend fun buildBackup(scope: Scope, categoryId: Long? = null): Backup.Bundle {
        val allCats = cats.allOnce()
        val byId = allCats.associateBy { it.id }
        val all = clips.exportAll()

        // 「親/子」の形にする。名前に / や \\ が入っていてもエスケープされる。
        fun pathOf(catId: Long?): String? {
            val c = catId?.let { byId[it] } ?: return null
            val parent = c.parentId?.let { byId[it] }
            return if (parent == null) Backup.encodePath(listOf(c.name))
            else Backup.encodePath(listOf(parent.name, c.name))
        }

        // メインタブを指定したときは、その配下のサブタブの中身もまとめて出す
        val inScope: (Long?) -> Boolean = { cid ->
            cid != null && (cid == categoryId || byId[cid]?.parentId == categoryId)
        }

        val selected = when (scope) {
            Scope.ALL -> all
            Scope.HISTORY -> all.filter { !it.pinned }
            Scope.SNIPPETS -> all.filter { it.pinned }
            Scope.ONE_TAB -> all.filter { it.pinned && inScope(it.categoryId) }
        }

        val catPaths = when (scope) {
            Scope.ALL, Scope.SNIPPETS -> allCats.mapNotNull { pathOf(it.id) }
            Scope.ONE_TAB -> allCats
                .filter { it.id == categoryId || it.parentId == categoryId }
                .mapNotNull { pathOf(it.id) }
            Scope.HISTORY -> emptyList()
        }

        val items = selected
            .sortedWith(compareBy<ClipEntry> { it.position }.thenByDescending { it.createdAt })
            .mapIndexed { i, e ->
                Backup.Item(
                    text = e.text,
                    title = e.title,
                    pinned = e.pinned,
                    category = pathOf(e.categoryId),
                    createdAt = e.createdAt,
                    position = i
                )
            }
        return Backup.Bundle(catPaths, items)
    }

    data class ImportResult(val added: Int, val skipped: Int, val tabs: Int)

    /**
     * @param replace true なら既存を全部消してから入れる
     */
    suspend fun restore(bundle: Backup.Bundle, replace: Boolean): ImportResult {
        var added = 0
        var skipped = 0
        var newTabs = 0

        db.withTransaction {
            if (replace) {
                clips.deleteAllClips()
                cats.deleteAll()
            }

            // 「親/子」のパスからタブを組み立てる
            val idOfPath = mutableMapOf<String, Long>()

            suspend fun ensurePath(path: String): Long? {
                idOfPath[path]?.let { return it }
                val parts = Backup.decodePath(path).filter { it.isNotBlank() }
                if (parts.isEmpty()) return null
                var parentId: Long? = null
                var id: Long? = null
                for (name in parts.take(2)) {
                    val existing = cats.findByName(name, parentId)
                    id = existing?.id ?: run {
                        val pos = if (parentId == null) cats.rootsOnce().size
                        else cats.childCount(parentId)
                        newTabs++
                        cats.insert(Category(name = name, position = pos, parentId = parentId))
                    }
                    parentId = id
                }
                id?.let { idOfPath[path] = it }
                return id
            }

            bundle.categories.forEach { ensurePath(it) }

            val toInsert = mutableListOf<ClipEntry>()
            val seenInBatch = mutableSetOf<String>()
            bundle.clips.forEach { item ->
                val text = item.text.trim()
                if (text.isEmpty()) return@forEach

                var catId: Long? = null
                if (item.pinned && !item.category.isNullOrBlank()) {
                    catId = ensurePath(item.category)
                }

                // ファイル内での重複も、既存との重複もまとめて弾く
                val key = (if (item.pinned) "S" else "H") + "\u0000" + text
                if (!seenInBatch.add(key)) { skipped++; return@forEach }

                if (!replace) {
                    val dup = if (item.pinned)
                        clips.findSnippetByText(text, -1L)
                    else
                        clips.findHistoryByText(text)
                    if (dup != null) { skipped++; return@forEach }
                }

                toInsert.add(
                    ClipEntry(
                        text = text,
                        title = item.title,
                        createdAt = item.createdAt,
                        updatedAt = item.createdAt,
                        pinned = item.pinned,
                        categoryId = catId,
                        position = item.position
                    )
                )
                added++
            }
            if (toInsert.isNotEmpty()) clips.insertAll(toInsert)

            // 取り込んだ結果、サブを持つメインの直下に定型文が残っていたら
            // 先頭のサブへ寄せて「メインとサブが混在しない」規則を保つ
            cats.rootsOnce().forEach { root ->
                val kids = cats.childrenOf(root.id)
                if (kids.isNotEmpty()) cats.moveClips(root.id, kids.first().id)
            }
        }
        return ImportResult(added, skipped, newTabs)
    }

    suspend fun exportAll() = clips.exportAll()

    companion object {
        const val MAX_TEXT_LEN = 100_000
        const val DEDUPE_WINDOW_MS = 1500L
    }
}
