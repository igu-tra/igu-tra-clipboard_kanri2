package com.clipkeep.data

import android.content.Context
import kotlinx.coroutines.flow.Flow

class ClipRepository(context: Context) {

    private val app = context.applicationContext
    private val db = ClipDatabase.get(app)
    private val clips = db.clipDao()
    private val cats = db.categoryDao()
    private val prefs = Settings(app)

    fun history(query: String): Flow<List<ClipEntry>> =
        if (query.isBlank()) clips.history() else clips.searchHistory(query.trim())

    fun categories(): Flow<List<Category>> = cats.all()
    fun allSnippets(): Flow<List<ClipEntry>> = clips.allSnippets()

    suspend fun recent(n: Int) = clips.recent(n)
    suspend fun byId(id: Long) = clips.byId(id)
    suspend fun historyCount() = clips.historyCount()

    /**
     * 捕捉したテキストを保存する。
     * 同じ本文が既に履歴にあれば新規追加せず、日時だけ更新して先頭に上げる。
     * 戻り値: 新しく記録されたら true（＝直前と同じ内容なら false）
     */
    suspend fun capture(text: String, sourceApp: String? = null): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        if (t.length > MAX_TEXT_LEN) return capture(t.take(MAX_TEXT_LEN), sourceApp)

        val existing = clips.findHistoryByText(t)
        val now = System.currentTimeMillis()
        if (existing != null) {
            // 既にある = 直前のコピーの再検知か、過去に同じものをコピーした
            if (now - existing.createdAt < DEDUPE_WINDOW_MS) return false
            clips.update(existing.copy(createdAt = now, updatedAt = now, sourceApp = sourceApp ?: existing.sourceApp))
            return true
        }
        clips.insert(ClipEntry(text = t, createdAt = now, updatedAt = now, sourceApp = sourceApp))
        val limit = prefs.historyLimit
        if (clips.historyCount() > limit) clips.trimHistory(limit)
        return true
    }

    suspend fun delete(id: Long) = clips.deleteById(id)
    suspend fun clearHistory() = clips.clearHistory()
    suspend fun update(e: ClipEntry) = clips.update(e)

    /** 履歴 -> 定型文へ昇格 */
    suspend fun pin(id: Long, categoryId: Long?) {
        val e = clips.byId(id) ?: return
        clips.update(e.copy(pinned = true, categoryId = categoryId, updatedAt = System.currentTimeMillis()))
    }

    suspend fun unpin(id: Long) {
        val e = clips.byId(id) ?: return
        clips.update(e.copy(pinned = false, categoryId = null, updatedAt = System.currentTimeMillis()))
    }

    suspend fun addSnippet(text: String, title: String?, categoryId: Long?): Long =
        clips.insert(
            ClipEntry(
                text = text, title = title?.ifBlank { null },
                pinned = true, categoryId = categoryId
            )
        )

    suspend fun addCategory(name: String): Long {
        val pos = cats.allOnce().size
        return cats.insert(Category(name = name, position = pos))
    }

    suspend fun renameCategory(c: Category, name: String) = cats.update(c.copy(name = name))

    suspend fun deleteCategory(id: Long) {
        cats.detachClips(id)
        cats.deleteById(id)
    }

    suspend fun exportAll() = clips.exportAll()

    companion object {
        const val MAX_TEXT_LEN = 100_000
        const val DEDUPE_WINDOW_MS = 1500L
    }
}
